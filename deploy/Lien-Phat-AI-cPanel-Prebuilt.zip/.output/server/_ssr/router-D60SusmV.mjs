import { r as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-D60SusmV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CRQvlF80.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var INTERACTIVE_SELECTOR = "button, a, input, select, textarea, [role='button'], [role='link'], [draggable='true']";
var LIGHT_CLASS_SELECTOR = ".bg-warm, .bg-white, [data-cursor-surface='light']";
function parseRgb(color) {
	const values = color.match(/[\d.]+/g)?.map(Number);
	if (!values || values.length < 3) return null;
	const [r, g, b, a = 1] = values;
	if (r === void 0 || g === void 0 || b === void 0) return null;
	return {
		r,
		g,
		b,
		a
	};
}
function surfaceIsLight(element) {
	let current = element instanceof HTMLElement ? element : null;
	while (current) {
		if (current.matches(LIGHT_CLASS_SELECTOR)) return true;
		const color = parseRgb(window.getComputedStyle(current).backgroundColor);
		if (color && color.a > .08) return (.2126 * color.r + .7152 * color.g + .0722 * color.b) / 255 > .62;
		current = current.parentElement;
	}
	return false;
}
function CursorSpotlight() {
	const primaryRef = (0, import_react.useRef)(null);
	const trailRef = (0, import_react.useRef)(null);
	const pulseRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
		const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
		if (!finePointer.matches || reducedMotion.matches) return;
		const primary = primaryRef.current;
		const trail = trailRef.current;
		const pulse = pulseRef.current;
		if (!primary || !trail || !pulse) return;
		let target = {
			x: window.innerWidth / 2,
			y: window.innerHeight / 2
		};
		let current = { ...target };
		let trailing = { ...target };
		let frame = 0;
		let visible = false;
		let theme = "dark";
		let pulseTimer = 0;
		const setPosition = (element, point) => {
			element.style.transform = `translate3d(${point.x}px, ${point.y}px, 0)`;
		};
		const updateContext = (x, y) => {
			const underneath = document.elementFromPoint(x, y);
			const nextTheme = surfaceIsLight(underneath) ? "light" : "dark";
			if (nextTheme !== theme) {
				theme = nextTheme;
				primary.dataset["theme"] = theme;
				trail.dataset["theme"] = theme;
				pulse.dataset["theme"] = theme;
			}
			primary.dataset["interactive"] = underneath?.closest(INTERACTIVE_SELECTOR) ? "true" : "false";
			const dialogOpen = Boolean(document.querySelector("[role='dialog'][data-state='open']"));
			primary.dataset["modal"] = dialogOpen ? "true" : "false";
			trail.dataset["modal"] = dialogOpen ? "true" : "false";
		};
		const animate = () => {
			current.x += (target.x - current.x) * .2;
			current.y += (target.y - current.y) * .2;
			trailing.x += (current.x - trailing.x) * .09;
			trailing.y += (current.y - trailing.y) * .09;
			setPosition(primary, current);
			setPosition(trail, trailing);
			frame = window.requestAnimationFrame(animate);
		};
		const onPointerMove = (event) => {
			if (event.pointerType && event.pointerType !== "mouse") return;
			target = {
				x: event.clientX,
				y: event.clientY
			};
			updateContext(event.clientX, event.clientY);
			if (!visible) {
				current = { ...target };
				trailing = { ...target };
				primary.dataset["visible"] = "true";
				trail.dataset["visible"] = "true";
				visible = true;
			}
		};
		const onPointerDown = (event) => {
			if (event.pointerType !== "mouse" || event.button !== 0) return;
			pulse.classList.remove("cursor-spotlight-pulse-active");
			setPosition(pulse, {
				x: event.clientX,
				y: event.clientY
			});
			pulse.offsetWidth;
			pulse.classList.add("cursor-spotlight-pulse-active");
			window.clearTimeout(pulseTimer);
			pulseTimer = window.setTimeout(() => pulse.classList.remove("cursor-spotlight-pulse-active"), 520);
		};
		const onPointerLeave = (event) => {
			if (event.relatedTarget) return;
			primary.dataset["visible"] = "false";
			trail.dataset["visible"] = "false";
			visible = false;
		};
		frame = window.requestAnimationFrame(animate);
		window.addEventListener("pointermove", onPointerMove, { passive: true });
		window.addEventListener("pointerdown", onPointerDown, { passive: true });
		document.documentElement.addEventListener("pointerleave", onPointerLeave);
		return () => {
			window.cancelAnimationFrame(frame);
			window.clearTimeout(pulseTimer);
			window.removeEventListener("pointermove", onPointerMove);
			window.removeEventListener("pointerdown", onPointerDown);
			document.documentElement.removeEventListener("pointerleave", onPointerLeave);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-hidden": "true",
		className: "cursor-spotlight-root",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: trailRef,
				className: "cursor-spotlight-trail",
				"data-theme": "dark"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: primaryRef,
				className: "cursor-spotlight-primary",
				"data-theme": "dark"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: pulseRef,
				className: "cursor-spotlight-pulse",
				"data-theme": "dark"
			})
		]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$1 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "LIEN PHAT AI" },
			{
				name: "description",
				content: "AI-powered business infrastructure for modern companies."
			},
			{
				name: "author",
				content: "LIEN PHAT AI"
			},
			{
				property: "og:title",
				content: "LIEN PHAT AI"
			},
			{
				property: "og:description",
				content: "Launch your AI-powered business operating system."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,600&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$1.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CursorSpotlight, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})]
	});
}
var $$splitComponentImporter = () => import("./routes-DE3kLrAT.mjs");
var rootRouteChildren = { IndexRoute: createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "AI Business Operating System | LIEN PHAT AI" },
		{
			name: "description",
			content: "Launch one connected AI operating system for CRM, voice, sales, marketing, websites, automation, and customer growth."
		},
		{
			property: "og:title",
			content: "Launch Your AI-Powered Business Operating System"
		},
		{
			property: "og:description",
			content: "Replace disconnected tools with one intelligent business ecosystem."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
}).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dw4ZjjCr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/runner/work/lien-phat-ai-operating-system/lien-phat-ai-operating-system/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BlC7t2kF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BlC7t2kF.js"
		} }]
	},
	"/": {
		filePath: "/home/runner/work/lien-phat-ai-operating-system/lien-phat-ai-operating-system/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CXTp6cpU.js"]
	}
} });
//#endregion
export { tsrStartManifest };

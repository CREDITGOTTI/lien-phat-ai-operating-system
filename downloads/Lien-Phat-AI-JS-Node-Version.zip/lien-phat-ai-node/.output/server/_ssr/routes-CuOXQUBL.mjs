import { r as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, a as Trigger2, i as Root2, n as Header$1, p as Slot, r as Item, t as Content2, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as supabase } from "./client-Bxc8_G9k.mjs";
import { A as ChevronDown, C as Layers, D as CircleDollarSign, E as CreditCard, F as Bot, I as ArrowRight, L as ArrowDown, M as ChartColumn, N as CalendarDays, O as ChevronRight, P as Building2, R as Activity, S as LayoutDashboard, T as Earth, _ as MessageSquare, a as UserRound, b as Megaphone, c as Sparkles, d as Radio, f as Plus, g as MicVocal, h as Pause, i as Users, j as Check, k as ChevronLeft, l as Send, m as Phone, n as X, o as StickyNote, p as Play, r as Workflow, s as Star, t as Zap, u as Search, v as MessageSquareText, w as GitBranch, x as Mail, y as Menu } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CuOXQUBL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold cursor-pointer transition-all duration-300 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			premium: "bg-primary text-primary-foreground shadow-[var(--shadow-glow)] hover:bg-primary-bright hover:-translate-y-0.5",
			luminous: "border border-foreground/20 bg-foreground/5 text-foreground backdrop-blur-md hover:bg-foreground/10",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-12 rounded-md px-7 text-sm",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header$1, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
function track(event, properties = {}) {
	if (typeof window === "undefined") return;
	const payload = {
		event,
		...properties,
		timestamp: (/* @__PURE__ */ new Date()).toISOString()
	};
	window.dispatchEvent(new CustomEvent("lienphat:analytics", { detail: payload }));
	window.dataLayer?.push(payload);
}
var contacts = [
	{
		name: "Avery Chen",
		company: "Evergreen Studio",
		email: "avery@example.com",
		phone: "+1 (202) 555-0101",
		source: "Website",
		tags: "High intent",
		stage: "Qualified",
		activity: "Replied 8 min ago",
		owner: "Alex",
		value: 8400
	},
	{
		name: "Jordan Blake",
		company: "Northline Homes",
		email: "jordan@example.com",
		phone: "+1 (202) 555-0102",
		source: "Google Ads",
		tags: "Real estate",
		stage: "Meeting",
		activity: "Booked 24 min ago",
		owner: "Sam",
		value: 4200
	},
	{
		name: "Taylor Morgan",
		company: "Atlas Wellness",
		email: "taylor@example.com",
		phone: "+1 (202) 555-0103",
		source: "Referral",
		tags: "Priority",
		stage: "Proposal",
		activity: "Opened email 1h ago",
		owner: "Alex",
		value: 6750
	},
	{
		name: "Casey Rivera",
		company: "Fieldwork Co.",
		email: "casey@example.com",
		phone: "+1 (202) 555-0104",
		source: "Social",
		tags: "New lead",
		stage: "Qualified",
		activity: "Form submitted 2h ago",
		owner: "Jamie",
		value: 3200
	}
];
var money = (n) => new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
}).format(n);
function Badge({ children, muted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded px-2 py-1 text-[10px] font-semibold ${muted ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"}`,
		children
	});
}
function Stats({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-x-5 gap-y-6 border-y border-border py-5 sm:grid-cols-4",
		children: items.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 break-words text-2xl font-semibold tabular-nums",
				children: value
			})]
		}, label))
	});
}
function Bars({ values = [
	32,
	45,
	38,
	62,
	51,
	70,
	65,
	84,
	74,
	95
], label = "Performance", secondary = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		"aria-label": label,
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-32 items-end gap-2 border-b border-border pt-4",
			children: values.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `flex-1 rounded-t-sm ${secondary ? "bg-muted-foreground/50" : "bg-primary/75"} transition-all duration-500 hover:bg-primary`,
				style: { height: `${v}%` },
				title: `${i + 1}: ${v}`
			}, i))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mt-3 flex justify-between text-[10px] text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Period start" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Period end" })
			]
		})]
	});
}
function SectionTitle({ children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-3 py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
			className: "text-sm font-semibold",
			children
		}), action]
	});
}
function DemoForm({ title, open, onClose, onSave, fields = ["Name"] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => {
			if (!v) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[85svh] overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Demo workspace only. No real messages, charges or external changes." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit: (e) => {
						e.preventDefault();
						onSave(Object.fromEntries(new FormData(e.currentTarget).entries()));
						onClose();
					},
					children: [fields.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: [f, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoComplete: "off",
							className: "mt-2 min-h-11",
							name: f,
							required: true,
							maxLength: 160,
							type: f === "Amount" ? "number" : f === "Email" ? "email" : f === "Date" ? "date" : "text",
							min: f === "Amount" ? 1 : void 0
						})]
					}, f)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "min-h-11 w-full",
						children: "Save to demo"
					})]
				})
			]
		})
	});
}
function Count({ value, suffix = "", prefix = "" }) {
	const [n, setN] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setN(value);
			return;
		}
		let frame = 0;
		const start = performance.now();
		const run = (now) => {
			const p = Math.min((now - start) / 650, 1);
			setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
			if (p < 1) frame = requestAnimationFrame(run);
		};
		frame = requestAnimationFrame(run);
		return () => cancelAnimationFrame(frame);
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		prefix,
		n.toLocaleString(),
		suffix
	] });
}
function ContactsPanel() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [action, setAction] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)({});
	const filtered = contacts.filter((c) => Object.values(c).join(" ").toLowerCase().includes(query.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { items: [
			["Contacts", "4"],
			["Qualified", "2"],
			["Owners", "3"],
			["Sources", "4"]
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full sm:w-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					"aria-label": "Search contacts",
					placeholder: "Search contacts, company, tags…",
					className: "min-h-11 pl-9",
					value: query,
					onChange: (e) => setQuery(e.target.value)
				})]
			}),
			children: "Contact database"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-w-0 gap-3 rounded-md border border-border p-4 transition-colors hover:border-primary/40 sm:grid-cols-[minmax(0,1fr)_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "h-auto min-w-0 justify-start p-0 text-left hover:bg-transparent hover:text-primary",
						onClick: () => setSelected(c),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
							children: c.name.split(" ").map((n) => n[0]).join("")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block truncate",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs font-normal text-muted-foreground",
								children: c.company
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: c.stage }), [
							[Phone, "Call"],
							[MessageSquare, "SMS"],
							[Mail, "Email"],
							[StickyNote, "Note"]
						].map(([Icon, label]) => {
							const I = Icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								className: "size-11",
								title: `${label} ${c.name}`,
								"aria-label": `${label} ${c.name}`,
								onClick: () => {
									setSelected(c);
									setAction(String(label));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, {})
							}, String(label));
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 text-xs text-muted-foreground sm:col-span-2 sm:grid-cols-2 xl:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "break-all",
								children: [
									c.email,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									c.phone
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Source: ",
								c.source,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Tag: ",
								c.tags
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.activity }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Owner: ", c.owner] })
						]
					})
				]
			}, c.name)), filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "py-12 text-center text-muted-foreground",
				children: [
					"No contacts match “",
					query,
					"”."
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(selected) && !action,
			onOpenChange: (v) => {
				if (!v) setSelected(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "left-auto right-0 top-0 h-svh max-h-svh translate-x-0 translate-y-0 overflow-y-auto rounded-none sm:rounded-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: selected?.name }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [selected?.company, " · Demo contact"] }),
					selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: selected.stage }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "break-all text-sm leading-7",
							children: [
								selected.email,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								selected.phone,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Owner: ",
								selected.owner,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Source: ",
								selected.source,
								" · ",
								selected.tags
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Recent activity" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "space-y-5 border-l border-primary/30 pl-5 text-sm",
							children: [
								...notes[selected.name] ?? [],
								selected.activity,
								"AI qualified lead · Today 09:12",
								"Welcome email delivered · Today 09:10",
								"Contact created · Yesterday 16:45"
							].map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block text-[10px] text-primary",
								children: i === 0 ? "LATEST" : "ACTIVITY"
							}), n] }, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-4",
							onClick: () => setAction("Note"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add note"]
						})
					] })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoForm, {
			title: `${action} · ${selected?.name ?? ""}`,
			open: Boolean(action),
			onClose: () => setAction(""),
			fields: action === "Call" ? ["Call note"] : ["Message"],
			onSave: (v) => {
				if (selected) setNotes((prev) => ({
					...prev,
					[selected.name]: [`${action === "Note" ? "Note saved" : action === "Call" ? "Simulated call logged" : `Demo ${action} queued`}: ${Object.values(v)[0]}`, ...prev[selected.name] ?? []]
				}));
			}
		})
	] });
}
function PipelinePanel() {
	const [deals, setDeals] = (0, import_react.useState)(contacts.map((c) => ({
		...c,
		stage: c.stage
	})));
	const stages = [
		"Qualified",
		"Meeting",
		"Proposal",
		"Won"
	];
	const [log, setLog] = (0, import_react.useState)("Avery Chen qualified by AI · 8 min ago");
	const [lost, setLost] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { items: [
			["Open pipeline", money(deals.filter((c) => c.stage !== "Won").reduce((s, c) => s + c.value, 0))],
			["Won", money(deals.filter((c) => c.stage === "Won").reduce((s, c) => s + c.value, 0))],
			["Lost", money(lost)],
			["Opportunities", String(deals.length)]
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Sales pipeline" }),
			children: "Opportunity board"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
			children: stages.map((stage) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between border-t-2 border-primary/50 pt-3 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: stage }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: deals.filter((d) => d.stage === stage).length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-24 space-y-3 bg-surface/50 p-2",
					children: [deals.filter((d) => d.stage === stage).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "hub-enter rounded-md border border-border bg-surface-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 truncate text-[10px] text-muted-foreground",
								children: c.company
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "my-4 text-lg font-semibold",
								children: money(c.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-[10px] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-3" }),
									c.owner,
									" · ",
									stage
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[10px]",
								children: stage === "Won" ? "Next: Customer onboarding" : "Next: " + (stage === "Qualified" ? "Book discovery" : stage === "Meeting" ? "Prepare proposal" : "Follow up tomorrow")
							}),
							stage !== "Won" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								className: "mt-3 min-h-11 w-full justify-between px-1 text-xs text-primary",
								"aria-label": `Advance ${c.name}`,
								onClick: () => {
									const next = stages[stages.indexOf(stage) + 1] ?? "Won";
									setDeals((prev) => prev.map((d) => d.name === c.name ? {
										...d,
										stage: next
									} : d));
									setLog(`${c.name} moved to ${next} · Just now`);
								},
								children: ["Advance ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "min-h-11 w-full text-xs text-muted-foreground",
								onClick: () => {
									setDeals((prev) => prev.filter((d) => d.name !== c.name));
									setLost((v) => v + c.value);
									setLog(`${c.name} marked lost · Just now`);
								},
								children: "Mark lost"
							})] })
						]
					}, c.name)), !deals.some((d) => d.stage === stage) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-[10px] text-muted-foreground",
						children: "No opportunities"
					})]
				})]
			}, stage))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "status",
			className: "mt-5 border-t border-border pt-4 text-xs text-primary",
			children: log
		})
	] });
}
var channels = [
	"SMS",
	"Email",
	"Web chat",
	"Social"
];
function MessagesPanel() {
	const [active, setActive] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)({});
	const [read, setRead] = (0, import_react.useState)([0]);
	const [typing, setTyping] = (0, import_react.useState)(false);
	const c = contacts[active] ?? contacts[0];
	if (!c) return null;
	const suggestion = `Hi ${c.name.split(" ")[0]}, absolutely. I can arrange a consultation tomorrow at 10:00 AM. Does that work for you?`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-0 overflow-hidden border border-border md:grid-cols-[180px_minmax(0,1fr)] xl:grid-cols-[180px_minmax(0,1fr)_160px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex overflow-x-auto border-b border-border md:block md:border-b-0 md:border-r",
				children: contacts.map((contact, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					"aria-pressed": active === i,
					onClick: () => {
						setActive(i);
						setDraft("");
						setRead((r) => [...r, i]);
					},
					className: `h-auto min-w-40 shrink-0 justify-start rounded-none border-b border-border p-4 text-left md:w-full md:min-w-0 ${active === i ? "bg-primary/10 text-primary" : ""}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs",
							children: [
								contact.name,
								" ",
								!read.includes(i) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-1.5 rounded-full bg-primary" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-2 block text-[10px] font-normal text-muted-foreground",
							children: [
								channels[i],
								" · ",
								i + 1,
								"m ago"
							]
						})]
					})
				}, contact.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 border-b border-border pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-sm",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: channels[active] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-h-60 space-y-4 py-5 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-center text-[10px] text-muted-foreground",
								children: "Wednesday, September 16 · Demo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-[90%] rounded-md bg-surface-raised p-3 leading-6",
								children: ["Hi, I’m interested in learning more. Can we book a consultation?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[9px] text-muted-foreground",
									children: "09:41 AM · Received"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto max-w-[90%] rounded-md bg-primary/10 p-3 leading-6",
								children: ["Of course! What time works best for you?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[9px] text-muted-foreground",
									children: "09:42 AM · AI assistant"
								})]
							}),
							(sent[active] ?? []).map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hub-enter ml-auto max-w-[90%] break-words rounded-md bg-primary/10 p-3 leading-6",
								children: [s, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[9px] text-muted-foreground",
									children: "Just now · Demo sent"
								})]
							}, i))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-y border-border py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-[10px] font-semibold text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }), "AI SUGGESTED REPLY"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs leading-6 text-muted-foreground",
								children: suggestion
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "min-h-11 px-0 text-xs text-primary",
								onClick: () => setDraft(suggestion),
								children: "Use suggestion"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "h-6 pt-2 text-[10px] text-muted-foreground",
						"aria-live": "polite",
						children: typing ? "You are typing…" : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							if (!draft.trim()) return;
							setSent((s) => ({
								...s,
								[active]: [...s[active] ?? [], draft.trim()]
							}));
							setDraft("");
							setTyping(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Compose message",
							placeholder: "Write a message…",
							value: draft,
							maxLength: 1e3,
							onChange: (e) => {
								setDraft(e.target.value);
								setTyping(Boolean(e.target.value));
							},
							className: "min-h-11 min-w-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "icon",
							className: "size-11 shrink-0",
							"aria-label": "Send demo message",
							disabled: !draft.trim(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border-t border-border p-4 text-xs xl:border-l xl:border-t-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Contact details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 leading-7 text-muted-foreground",
						children: [
							c.company,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							c.phone,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Owner: ",
							c.owner,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Source: ",
							c.source
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: c.stage })
					})
				]
			})
		]
	}) });
}
function AppointmentsPanel() {
	const [mode, setMode] = (0, import_react.useState)("Week");
	const [selected, setSelected] = (0, import_react.useState)("Wed 16");
	const [rows, setRows] = (0, import_react.useState)([
		{
			name: "Avery Chen",
			type: "Discovery call",
			owner: "Alex",
			status: "Confirmed",
			source: "AI Voice",
			day: "Wed 16",
			time: "10:00"
		},
		{
			name: "Jordan Blake",
			type: "Product walkthrough",
			owner: "Sam",
			status: "Pending",
			source: "Website",
			day: "Thu 17",
			time: "11:00"
		},
		{
			name: "Taylor Morgan",
			type: "Strategy review",
			owner: "Alex",
			status: "Completed",
			source: "Calendar link",
			day: "Mon 14",
			time: "14:00"
		},
		{
			name: "Casey Rivera",
			type: "Onboarding",
			owner: "Jamie",
			status: "No-show",
			source: "Web chat",
			day: "Tue 15",
			time: "09:00"
		}
	]);
	const [reschedule, setReschedule] = (0, import_react.useState)(null);
	const days = [
		"Mon 14",
		"Tue 15",
		"Wed 16",
		"Thu 17",
		"Fri 18"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1",
				children: ["Day", "Week"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "min-h-11",
					variant: mode === m ? "default" : "ghost",
					"aria-pressed": mode === m,
					onClick: () => setMode(m),
					children: m
				}, m))
			}),
			children: "September 14–18, 2026"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-5 border-y border-border",
			children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: `min-h-14 rounded-none px-1 text-[10px] sm:text-xs ${d === selected ? "bg-primary/10 text-primary" : ""}`,
				variant: "ghost",
				"aria-pressed": d === selected,
				onClick: () => {
					setSelected(d);
					setMode("Day");
				},
				children: d
			}, d))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mt-4 grid gap-2 ${mode === "Week" ? "sm:grid-cols-5" : ""}`,
			children: (mode === "Week" ? days : [selected]).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 border-l border-border pl-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-[10px] text-muted-foreground",
						children: d
					}),
					rows.filter((r) => r.day === d && r.status !== "Cancelled").map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 rounded border-l-2 border-primary bg-primary/10 p-2 text-[10px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-primary",
								children: r.time
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-semibold",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted-foreground",
								children: r.type
							})
						]
					}, r.name)),
					!rows.some((r) => r.day === d && r.status !== "Cancelled") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-6 text-[10px] text-muted-foreground",
						children: "Available"
					})
				]
			}, d))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Appointment schedule" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-border",
			children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 py-4 sm:grid-cols-[minmax(0,1fr)_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold",
						children: [
							r.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-xs font-normal text-muted-foreground",
								children: [
									r.day,
									" · ",
									r.time
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							r.type,
							" · ",
							r.owner,
							" · ",
							r.source
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							muted: r.status === "Cancelled" || r.status === "No-show",
							children: r.status
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "min-h-11 text-xs",
						disabled: [
							"Cancelled",
							"Completed",
							"No-show"
						].includes(r.status),
						onClick: () => setReschedule(i),
						children: "Reschedule"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "min-h-11 text-xs text-muted-foreground",
						disabled: [
							"Cancelled",
							"Completed",
							"No-show"
						].includes(r.status),
						onClick: () => setRows((rs) => rs.map((a, j) => j === i ? {
							...a,
							status: "Cancelled"
						} : a)),
						children: "Cancel"
					})]
				})]
			}, r.name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-xs text-primary",
			children: "Next available: Friday, September 18 · 10:00, 11:00, 14:00"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: reschedule !== null,
			onOpenChange: (v) => {
				if (!v) setReschedule(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Reschedule appointment" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Choose a demo slot on Friday, September 18." }),
				[
					"10:00",
					"11:00",
					"14:00"
				].map((time) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "min-h-11",
					variant: "outline",
					onClick: () => {
						setRows((rs) => rs.map((a, j) => j === reschedule ? {
							...a,
							day: "Fri 18",
							time,
							status: "Confirmed"
						} : a));
						setReschedule(null);
					},
					children: time
				}, time))
			] })
		})
	] });
}
var initialCampaigns = [
	{
		name: "Welcome series",
		type: "Email",
		status: "Active",
		audience: 1200,
		sent: 1080,
		delivered: 1064,
		open: 642,
		click: 184,
		reply: 72,
		booked: 18,
		date: "Sep 16, 09:00"
	},
	{
		name: "Appointment reminders",
		type: "SMS",
		status: "Active",
		audience: 240,
		sent: 216,
		delivered: 214,
		open: 196,
		click: 86,
		reply: 42,
		booked: 14,
		date: "Sep 16, 10:00"
	},
	{
		name: "New lead journey",
		type: "Nurture",
		status: "Active",
		audience: 480,
		sent: 420,
		delivered: 416,
		open: 310,
		click: 120,
		reply: 68,
		booked: 16,
		date: "Sep 16, 12:00"
	},
	{
		name: "Reconnect this fall",
		type: "Reactivation",
		status: "Scheduled",
		audience: 850,
		sent: 0,
		delivered: 0,
		open: 0,
		click: 0,
		reply: 0,
		booked: 0,
		date: "Sep 18, 09:00"
	},
	{
		name: "September update",
		type: "Broadcast",
		status: "Draft",
		audience: 2400,
		sent: 0,
		delivered: 0,
		open: 0,
		click: 0,
		reply: 0,
		booked: 0,
		date: "Not scheduled"
	}
];
var chartSeries = {
	Sends: [
		18,
		34,
		51,
		68,
		76,
		88,
		96,
		100
	],
	Opens: [
		4,
		13,
		24,
		38,
		51,
		67,
		84,
		92
	],
	Clicks: [
		1,
		5,
		11,
		18,
		31,
		44,
		58,
		72
	],
	Replies: [
		0,
		2,
		5,
		9,
		16,
		25,
		37,
		51
	]
};
var activityEvents = [
	["SMS delivered", "2 sec ago"],
	["Email opened", "6 sec ago"],
	["Link clicked", "12 sec ago"],
	["Reply received", "21 sec ago"],
	["Appointment booked", "38 sec ago"]
];
var clamp = (value) => Math.max(0, Math.min(1, value));
function CampaignsPanel() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(0);
	const [chartMetric, setChartMetric] = (0, import_react.useState)("Sends");
	const [rows, setRows] = (0, import_react.useState)(initialCampaigns);
	const [simulations, setSimulations] = (0, import_react.useState)(() => Object.fromEntries(initialCampaigns.map((c) => [c.name, { progress: c.status === "Active" ? 100 : 0 }])));
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setSimulations((current) => {
			let changed = false;
			const next = { ...current };
			rows.forEach((c) => {
				const value = current[c.name]?.progress ?? 0;
				if (c.status === "Active" && value < 100) {
					next[c.name] = { progress: Math.min(100, value + 2) };
					changed = true;
				}
			});
			return changed ? next : current;
		}), 180);
		return () => window.clearInterval(timer);
	}, [rows]);
	const c = rows[selected] ?? rows[0];
	if (!c) return null;
	const progress = simulations[c.name]?.progress ?? 0;
	const targets = {
		audience: c.audience,
		sent: c.sent || Math.round(c.audience * .9),
		delivered: c.delivered || Math.round(c.audience * .887),
		open: c.open || Math.round(c.audience * .535),
		click: c.click || Math.round(c.audience * .153),
		reply: c.reply || Math.round(c.audience * .06),
		booked: c.booked || Math.max(1, Math.round(c.audience * .015))
	};
	const live = {
		audience: targets.audience,
		sent: Math.round(targets.sent * clamp(progress / 34)),
		delivered: Math.round(targets.delivered * clamp((progress - 9) / 35)),
		open: Math.round(targets.open * clamp((progress - 24) / 42)),
		click: Math.round(targets.click * clamp((progress - 42) / 37)),
		reply: Math.round(targets.reply * clamp((progress - 59) / 31)),
		booked: Math.round(targets.booked * clamp((progress - 76) / 24))
	};
	const flow = [
		["Audience", live.audience],
		["Sent", live.sent],
		["Delivered", live.delivered],
		["Opened", live.open],
		["Clicked", live.click],
		["Replied", live.reply],
		["Booked", live.booked]
	];
	const kpis = [
		["Delivery Rate", live.sent ? live.delivered / live.sent * 100 : 0],
		["Open Rate", live.delivered ? live.open / live.delivered * 100 : 0],
		["Click Rate", live.open ? live.click / live.open * 100 : 0],
		["Reply Rate", live.click ? live.reply / live.click * 100 : 0],
		["Booking Rate", live.reply ? live.booked / live.reply * 100 : 0]
	];
	const visibleEvents = Math.min(activityEvents.length, Math.floor(progress / 18));
	const buttonLabel = c.status === "Active" ? "Pause" : c.status === "Paused" ? "Resume" : "Activate";
	const setCampaignStatus = () => {
		if (c.status === "Active") {
			setRows((current) => current.map((row, i) => i === selected ? {
				...row,
				status: "Paused"
			} : row));
			return;
		}
		if (c.status !== "Paused") setSimulations((current) => ({
			...current,
			[c.name]: { progress: 0 }
		}));
		setRows((current) => current.map((row, i) => i === selected ? {
			...row,
			status: "Active"
		} : row));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { items: [
			["Campaigns", String(rows.length)],
			["Messages sent", "1,716"],
			["Delivered", "98.7%"],
			["Replies", "182"]
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "min-h-11",
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Create Campaign"]
			}),
			children: "Campaign command center"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				"aria-pressed": selected === i,
				onClick: () => setSelected(i),
				className: `grid h-auto min-h-20 w-full grid-cols-[minmax(0,1fr)_auto] gap-3 whitespace-normal rounded-md border p-4 text-left ${selected === i ? "border-primary/50 bg-primary/5" : "border-border"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "block text-xs",
						children: r.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-2 block text-[10px] font-normal text-muted-foreground",
						children: [
							r.type,
							" · ",
							r.audience.toLocaleString(),
							" contacts · ",
							r.date
						]
					})]
				}), r.status === "Active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 rounded border border-primary/40 bg-primary/10 px-2 py-1 text-[10px] font-semibold text-primary shadow-[var(--shadow-glow)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "campaign-live-dot size-1.5 rounded-full bg-primary" }), "ACTIVE"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					muted: true,
					children: r.status
				})]
			}, r.name + i))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: c.status === "Active" ? "outline" : "default",
				className: `min-h-11 text-xs ${c.status === "Active" ? "border-primary/50 text-primary" : ""}`,
				onClick: setCampaignStatus,
				children: [c.status === "Active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), buttonLabel]
			}),
			children: [c.name, " performance"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			"aria-label": "Simulated live campaign performance",
			className: `overflow-hidden rounded-md border p-4 sm:p-5 ${c.status === "Active" ? "campaign-live-panel border-primary/40 bg-primary/5" : "border-border bg-surface/30"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-[10px] font-bold text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3" }), "LIVE DEMO · SIMULATED PERFORMANCE"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: "Fictional campaign activity for product demonstration only."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						role: "status",
						"aria-live": "polite",
						className: "inline-flex items-center gap-2 text-[10px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${c.status === "Active" ? "campaign-live-dot bg-primary" : "bg-muted-foreground"}` }), c.status === "Active" ? progress < 100 ? "RUNNING" : "SEQUENCE COMPLETE" : c.status === "Paused" ? "PAUSED" : "READY TO LAUNCH"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid grid-cols-2 gap-px overflow-hidden rounded border border-border bg-border sm:grid-cols-4 lg:grid-cols-8",
					children: [
						["Audience", live.audience],
						["Sent", live.sent],
						["Delivered", live.delivered],
						["Opened", live.open],
						["Clicked", live.click],
						["Replied", live.reply],
						["Booked", live.booked],
						["Conversion", `${live.audience ? (live.booked / live.audience * 100).toFixed(1) : "0.0"}%`]
					].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 bg-background p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[9px] text-muted-foreground",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 break-words text-lg font-semibold tabular-nums text-foreground",
							children: typeof value === "number" ? value.toLocaleString() : value
						})]
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold",
							children: "Delivery path"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[9px] text-muted-foreground",
							children: [Math.round(progress), "% simulated"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "campaign-flow grid gap-3 md:grid-cols-7",
						children: flow.map(([label, value], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: `campaign-flow-item relative min-w-0 rounded border p-3 ${progress >= i * 13 ? "is-live border-primary/45 bg-primary/10" : "border-border bg-background"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] text-muted-foreground",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold tabular-nums",
								children: value.toLocaleString()
							})]
						}, label))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid grid-cols-2 gap-2 lg:grid-cols-5",
					children: kpis.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded border border-border bg-background p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] text-muted-foreground",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-base font-semibold tabular-nums",
								children: [value.toFixed(1), "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1 overflow-hidden rounded bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-primary transition-[width] duration-500",
									style: { width: `${Math.min(value, 100)}%` }
								})
							})
						]
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_240px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold",
								children: "Performance over time"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-label": "Chart metric",
								className: "flex flex-wrap gap-1",
								children: Object.keys(chartSeries).map((metric) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									"aria-pressed": chartMetric === metric,
									onClick: () => setChartMetric(metric),
									className: `min-h-11 px-3 text-[10px] ${chartMetric === metric ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
									children: metric
								}, metric))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							"aria-label": `${chartMetric} simulated activity chart`,
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-36 items-end gap-2 border-b border-border",
								children: chartSeries[chartMetric].map((value, i) => {
									const height = value * clamp((progress - i * 7) / 48);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "group flex h-full flex-1 items-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full rounded-t-sm bg-primary/75 transition-[height,opacity] duration-500 group-hover:bg-primary",
											style: {
												height: `${height}%`,
												opacity: height ? 1 : .18
											},
											title: `${chartMetric} period ${i + 1}: ${Math.round(height)}`
										})
									}, i);
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
								className: "mt-2 flex justify-between text-[9px] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Launch" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [chartMetric, " · simulated"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Now" })
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "border-t border-border pt-5 lg:border-l lg:border-t-0 lg:pl-5 lg:pt-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-xs font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4 text-primary" }), "Recent activity"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-live": "polite",
							className: "mt-4 min-h-36 space-y-2",
							children: visibleEvents === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] leading-5 text-muted-foreground",
								children: "Activity will appear here when the simulated campaign launches."
							}) : activityEvents.slice(0, visibleEvents).reverse().map(([event, time]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hub-enter border-l-2 border-primary bg-primary/5 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-medium",
									children: event
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[9px] text-muted-foreground",
									children: ["Demo · ", time]
								})]
							}, event))
						})]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoForm, {
			title: "Create Campaign",
			open,
			onClose: () => setOpen(false),
			fields: [
				"Campaign name",
				"Channel",
				"Audience",
				"Date"
			],
			onSave: (v) => {
				const name = v["Campaign name"] ?? "Untitled campaign";
				const audience = Math.max(1, Number(v["Audience"]) || 1200);
				setRows((current) => [...current, {
					name,
					type: v["Channel"] ?? "Email",
					status: "Draft",
					audience,
					sent: 0,
					delivered: 0,
					open: 0,
					click: 0,
					reply: 0,
					booked: 0,
					date: v["Date"] ?? "Not scheduled"
				}]);
				setSimulations((current) => ({
					...current,
					[name]: { progress: 0 }
				}));
				setSelected(rows.length);
			}
		})
	] });
}
var nodes = [
	[
		"Lead Captured",
		"Trigger",
		"Website form submitted",
		"Instant"
	],
	[
		"AI Qualification",
		"Condition",
		"Continue if lead score ≥ 70",
		"Under 10 seconds"
	],
	[
		"SMS",
		"Action",
		"Send personalized welcome SMS",
		"Immediately"
	],
	[
		"Email",
		"Action",
		"Send consultation overview",
		"Wait 5 minutes"
	],
	[
		"Calendar Booking",
		"Condition",
		"Continue when a slot is booked",
		"Wait up to 24 hours"
	],
	[
		"CRM Update",
		"Action",
		"Move opportunity to Meeting",
		"Immediately"
	],
	[
		"Reminder",
		"Delay",
		"Send appointment reminder",
		"1 hour before meeting"
	],
	[
		"Sales Notification",
		"Action",
		"Notify assigned owner",
		"Immediately"
	]
];
function AutomationPanel() {
	const [active, setActive] = (0, import_react.useState)(0);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [executions, setExecutions] = (0, import_react.useState)([
		"Avery Chen · Completed · 09:41",
		"Jordan Blake · Waiting for booking · 09:32",
		"Taylor Morgan · Completed · 09:15"
	]);
	const [enabled, setEnabled] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		let step = 0;
		const timer = window.setInterval(() => {
			step += 1;
			if (step > 7) {
				setRunning(false);
				setExecutions((es) => ["Demo lead · Completed · Just now", ...es]);
				clearInterval(timer);
			} else setActive(step);
		}, 850);
		return () => clearInterval(timer);
	}, [running]);
	const n = nodes[active] ?? nodes[0];
	if (!n) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					"aria-pressed": enabled,
					className: "min-h-11 text-xs",
					onClick: () => setEnabled((v) => !v),
					children: [enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), enabled ? "Pause workflow" : "Enable workflow"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					disabled: !enabled || running,
					className: "min-h-11 text-xs",
					onClick: () => {
						setActive(0);
						setRunning(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), running ? "Running…" : "Run demo"]
				})]
			}),
			children: "Lead-to-booking workflow"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-5 text-xs text-muted-foreground",
			children: [
				"Version 2.4 · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-primary",
					children: enabled ? "Published" : "Paused"
				}),
				" · 3 recent executions"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_220px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scan-grid grid gap-x-5 gap-y-2 rounded-md border border-border p-4 sm:grid-cols-2",
				children: nodes.map(([name, type], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						"aria-pressed": active === i,
						onClick: () => setActive(i),
						className: `h-auto min-h-20 w-full justify-start whitespace-normal border p-3 text-left ${i <= active ? "border-primary/60 bg-primary/10" : "border-border bg-background"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workflow, { className: "shrink-0 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-[9px] font-normal text-muted-foreground",
									children: [
										"0",
										i + 1,
										" / ",
										type
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs",
									children: name
								})]
							}),
							i < active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "ml-auto shrink-0 text-primary" })
						]
					}), i < 7 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: `mx-auto my-1 size-4 ${i < active ? "text-primary" : "text-muted-foreground"}` })]
				}, name))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "min-w-0 border-l border-border pl-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: n[1] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mt-4 text-lg font-semibold",
						children: n[0]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs leading-6 text-muted-foreground",
						children: n[2]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[10px] text-primary",
						children: "TIMING"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs",
						children: n[3]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[10px] text-primary",
						children: "STATUS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "mt-2 text-xs",
						children: running ? "Executing demo" : enabled ? "Ready" : "Paused"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Recent executions" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-4",
						children: executions.slice(0, 4).map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-[10px] leading-5 text-muted-foreground",
							children: e
						}, i))
					})
				]
			})]
		})
	] });
}
function ReviewsPanel() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [requested, setRequested] = (0, import_react.useState)(32);
	const [reply, setReply] = (0, import_react.useState)(null);
	const [published, setPublished] = (0, import_react.useState)([]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { items: [
			["Overall rating", "4.8 / 5"],
			["Demo reviews", "128"],
			["Positive sentiment", "94%"],
			["Requests sent", String(requested)]
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "min-h-11",
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Request Review"]
			}),
			children: "Reputation overview"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium",
					children: "Sentiment trend"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, { label: "Positive reviews" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-4 text-[10px] text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Positive 94% ↑ 6%" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Neutral 4%" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Negative 2% ↓ 3%" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
					values: [
						45,
						35,
						40,
						25,
						20,
						15,
						12,
						10
					],
					label: "Negative reviews",
					secondary: true
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-l border-border pl-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium",
						children: "Review request campaign"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-2xl",
						children: "Post-appointment follow-up"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs leading-6 text-muted-foreground",
						children: "SMS request sent 24 hours after a completed appointment."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Active" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 text-xs",
						children: [requested, " sent · 18 opened · 12 reviewed"]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Recent reviews · fictional examples" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-border",
			children: [
				{
					name: "Demo customer A",
					stars: 5,
					source: "Google",
					text: "Clear communication and a helpful consultation.",
					sentiment: "Positive"
				},
				{
					name: "Demo customer B",
					stars: 4,
					source: "Facebook",
					text: "Easy booking process. A few more time slots would help.",
					sentiment: "Positive"
				},
				{
					name: "Demo customer C",
					stars: 2,
					source: "Google",
					text: "I had to wait longer than expected for a follow-up.",
					sentiment: "Negative"
				}
			].map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: r.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							muted: r.sentiment === "Negative",
							children: [
								r.source,
								" · ",
								r.sentiment
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "my-3 flex gap-1",
						"aria-label": `${r.stars} out of 5 stars`,
						children: Array.from({ length: 5 }, (_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-3 ${j < r.stars ? "fill-primary text-primary" : "text-muted-foreground"}` }, j))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-6 text-muted-foreground",
						children: r.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[10px] text-muted-foreground",
						children: [
							"Sep ",
							16 - i,
							", 2026"
						]
					}),
					published.includes(i) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "mt-4 text-xs text-primary",
						children: "Demo response saved"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "mt-2 min-h-11 px-0 text-xs text-primary",
						onClick: () => setReply(reply === i ? null : i),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "AI response suggestion"]
					}),
					reply === i && !published.includes(i) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 border-l-2 border-primary pl-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-6",
							children: r.stars > 3 ? "Thank you for sharing your experience. We appreciate your feedback and look forward to helping you again." : "Thank you for bringing this to our attention. We’re sorry about the delay and would welcome the chance to resolve it directly."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "mt-3 min-h-11 text-xs",
							onClick: () => {
								setPublished((p) => [...p, i]);
								setReply(null);
							},
							children: "Save demo response"
						})]
					})
				]
			}, r.name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoForm, {
			title: "Request Review",
			fields: ["Customer name", "Email"],
			open,
			onClose: () => setOpen(false),
			onSave: () => setRequested((n) => n + 1)
		})
	] });
}
function PaymentsPanel() {
	const [action, setAction] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([
		{
			id: "INV-1048",
			name: "Evergreen Studio",
			amount: 8400,
			status: "Paid",
			date: "Sep 16, 2026"
		},
		{
			id: "INV-1047",
			name: "Northline Homes",
			amount: 4200,
			status: "Pending",
			date: "Sep 15, 2026"
		},
		{
			id: "INV-1046",
			name: "Atlas Wellness",
			amount: 6750,
			status: "Paid",
			date: "Sep 14, 2026"
		},
		{
			id: "INV-1045",
			name: "Fieldwork Co.",
			amount: 3200,
			status: "Failed",
			date: "Sep 12, 2026"
		}
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { items: [
			["Collected", money(rows.filter((r) => r.status === "Paid").reduce((a, r) => a + r.amount, 0))],
			["Pending", money(rows.filter((r) => r.status === "Pending").reduce((a, r) => a + r.amount, 0))],
			["Failed", String(rows.filter((r) => r.status === "Failed").length)],
			["Subscriptions", "12 active"]
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "min-h-11 text-xs",
					onClick: () => setAction("Payment Link"),
					children: "Payment Link"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "min-h-11 text-xs",
					onClick: () => setAction("Create Invoice"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Create Invoice"]
				})]
			}),
			children: "Revenue performance"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, { label: "Collected revenue" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				"aria-label": "Invoice status",
				className: "min-h-11 rounded border border-border bg-background px-3 text-xs",
				value: filter,
				onChange: (e) => setFilter(e.target.value),
				children: [
					"All",
					"Paid",
					"Pending",
					"Failed"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
			}),
			children: "Transactions"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-border",
			children: rows.filter((r) => filter === "All" || r.status === filter).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[minmax(0,1fr)_auto] gap-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-semibold",
						children: r.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[10px] text-muted-foreground",
						children: [
							r.id,
							" · ",
							r.date
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm font-semibold",
							children: money(r.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							muted: r.status !== "Paid",
							children: r.status
						}),
						r.status === "Failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "ml-2 min-h-11 px-2 text-xs",
							onClick: () => {
								setRows((rs) => rs.map((t) => t.id === r.id ? {
									...t,
									status: "Pending"
								} : t));
								setNotice(`${r.id} retry queued in demo`);
							},
							children: "Retry"
						})
					]
				})]
			}, r.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Subscriptions & activity" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs leading-7 text-muted-foreground",
			children: [
				"Business Hub · 8 subscriptions · $776 / month",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"AI Employee · 4 subscriptions · $788 / month",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"INV-1048 paid · Today 09:42",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"INV-1047 issued · Yesterday 14:20"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "status",
			className: "mt-4 break-all text-xs text-primary",
			children: notice
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoForm, {
			title: action,
			fields: ["Customer", "Amount"],
			open: Boolean(action),
			onClose: () => setAction(""),
			onSave: (v) => {
				const id = `INV-${1049 + rows.length - 4}`;
				setRows((rs) => [{
					id,
					name: v["Customer"] ?? "Demo customer",
					amount: Number(v["Amount"]) || 1,
					status: "Pending",
					date: "Demo · Just now"
				}, ...rs]);
				setNotice(action === "Payment Link" ? `Demo payment link created: demo://payments/${id} (not payable)` : `${id} created in demo`);
				setFilter("All");
			}
		})
	] });
}
function AnalyticsPanel() {
	const [range, setRange] = (0, import_react.useState)("30");
	const factor = range === "7" ? .28 : range === "90" ? 2.7 : 1;
	const metrics = [
		[
			"Leads captured",
			Math.round(1248 * factor),
			"",
			""
		],
		[
			"Avg. response time",
			18,
			"",
			"s"
		],
		[
			"Appointments booked",
			Math.round(186 * factor),
			"",
			""
		],
		[
			"Close rate",
			32,
			"",
			"%"
		],
		[
			"Revenue attributed",
			Math.round(68400 * factor),
			"$",
			""
		],
		[
			"Pipeline value",
			Math.round(142850 * factor),
			"$",
			""
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				"aria-label": "Analytics date range",
				className: "min-h-11 rounded border border-border bg-background px-3 text-xs",
				value: range,
				onChange: (e) => setRange(e.target.value),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "7",
						children: "Last 7 days"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "30",
						children: "Last 30 days"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "90",
						children: "Last 90 days"
					})
				]
			}),
			children: "Executive overview"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-x-5 gap-y-7 border-y border-border py-6 lg:grid-cols-3",
			children: metrics.map(([label, value, prefix, suffix]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 break-words text-2xl font-semibold tabular-nums",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
							value,
							prefix,
							suffix
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[10px] text-primary",
						children: [label === "Avg. response time" ? "↓ 24% faster" : "↑ 12.8%", " vs prior period"]
					})
				]
			}, label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Growth trends" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
			values: range === "7" ? [
				34,
				42,
				58,
				45,
				67,
				82,
				94
			] : range === "90" ? [
				20,
				25,
				38,
				34,
				50,
				61,
				64,
				76,
				82,
				99
			] : [
				30,
				42,
				38,
				58,
				53,
				70,
				72,
				84,
				79,
				95
			],
			label: `Lead volume · ${range} days`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-8 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Lead source breakdown" }), [
				["Website", 42],
				["Google Ads", 28],
				["Social", 18],
				["Referral", 12]
			].map(([name, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 flex justify-between text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [v, "%"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-primary/75",
						style: { width: `${v}%` }
					})
				})]
			}, name))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Conversion funnel" }), [
				[
					"Captured",
					1248,
					100
				],
				[
					"Qualified",
					684,
					76
				],
				[
					"Booked",
					186,
					52
				],
				[
					"Won",
					60,
					30
				]
			].map(([label, count, width]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex min-h-11 items-center justify-between gap-3 border-l-2 border-primary bg-primary/10 px-3 text-xs",
				style: {
					width: `${width}%`,
					minWidth: "140px"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(Number(count) * factor) })]
			}, label))] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Campaign performance" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: [
				[
					"Welcome series",
					"59.4% open",
					"17% click"
				],
				[
					"Appointment reminders",
					"90.7% open",
					"19.4% reply"
				],
				[
					"New lead journey",
					"73.8% open",
					"28.6% click"
				]
			].map(([name, a, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-between gap-3 border-b border-border pb-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [
						a,
						" · ",
						b
					]
				})]
			}, name))
		})
	] });
}
var sections = [
	[
		"Contacts",
		Users,
		ContactsPanel,
		"Customer intelligence"
	],
	[
		"Pipeline",
		LayoutDashboard,
		PipelinePanel,
		"Sales overview"
	],
	[
		"Messages",
		MessageSquare,
		MessagesPanel,
		"Unified inbox"
	],
	[
		"Appointments",
		CalendarDays,
		AppointmentsPanel,
		"Team calendar"
	],
	[
		"Campaigns",
		Megaphone,
		CampaignsPanel,
		"Growth operations"
	],
	[
		"Automation",
		GitBranch,
		AutomationPanel,
		"Workflow studio"
	],
	[
		"Reviews",
		Star,
		ReviewsPanel,
		"Reputation management"
	],
	[
		"Payments",
		CreditCard,
		PaymentsPanel,
		"Revenue operations"
	],
	[
		"Analytics",
		ChartColumn,
		AnalyticsPanel,
		"Business intelligence"
	]
];
function BusinessHub() {
	const [active, setActive] = (0, import_react.useState)("Pipeline");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "business-hub",
		"aria-label": "Business Hub demo",
		className: "border-y border-border bg-surface py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-4xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-primary",
						children: "Single source of truth"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-balance text-4xl font-medium leading-[1.02] sm:text-6xl lg:text-7xl",
						children: "One Command Center For Your Customer Journey."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted-foreground",
						children: "Demo workspace · All contacts, activity, reviews and financial figures are fictional."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 min-w-0 overflow-hidden rounded-lg border border-border bg-background",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-border px-4 py-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 shrink-0 place-items-center overflow-hidden rounded-full bg-warm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/lienphat-icon-approved.webp",
								alt: "",
								className: "size-[86%] object-contain"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs font-bold",
							children: ["LIEN PHAT ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "BUSINESS HUB"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-[9px] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }), "DEMO"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-w-0 lg:grid-cols-[190px_minmax(0,1fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "min-w-0 border-b border-border bg-surface/40 lg:border-b-0 lg:border-r",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden px-5 pb-3 pt-6 text-[9px] font-semibold text-muted-foreground lg:block",
								children: "WORKSPACE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-label": "Business Hub sections",
								className: "flex gap-1 overflow-x-auto p-3 lg:flex-col lg:overflow-visible",
								children: sections.map(([name, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									"aria-pressed": active === name,
									"aria-controls": `hub-panel-${name}`,
									variant: "ghost",
									onClick: (e) => {
										setActive(name);
										e.currentTarget.parentElement?.scrollTo({
											left: e.currentTarget.offsetLeft - e.currentTarget.parentElement.offsetLeft - 12,
											behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
										});
									},
									className: `min-h-11 shrink-0 justify-start gap-3 px-3 text-xs lg:w-full ${active === name ? "bg-primary text-primary-foreground hover:bg-primary-bright" : "text-muted-foreground hover:bg-primary/10 hover:text-primary"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {}),
										name,
										active === name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto hidden lg:block" })
									]
								}, name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-5 mt-16 hidden border-t border-border pb-6 pt-5 lg:block",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium",
										children: "Demo team"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-[10px] text-muted-foreground",
										children: "Alex · Sam · Jamie"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex -space-x-1",
										children: [
											"A",
											"S",
											"J"
										].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-7 place-items-center rounded-full border-2 border-background bg-primary/15 text-[9px] text-primary",
											children: n
										}, n))
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 p-4 sm:p-6",
						children: sections.map(([name, , Panel, subtitle]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: `hub-panel-${name}`,
							role: "region",
							"aria-label": `${name} panel`,
							hidden: active !== name,
							className: active === name ? "hub-enter" : "",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[9px] font-semibold uppercase text-muted-foreground",
										children: subtitle
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 text-2xl font-semibold",
										children: name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-border px-3 py-1 text-[10px] text-primary",
									children: "Sandbox"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {})]
						}, name))
					})]
				})]
			})]
		})
	});
}
var MODULES = [
	{
		name: "AI Voice",
		Icon: MicVocal
	},
	{
		name: "CRM",
		Icon: Layers
	},
	{
		name: "Automation",
		Icon: Workflow
	},
	{
		name: "Payments",
		Icon: CircleDollarSign
	},
	{
		name: "Calendar",
		Icon: CalendarDays
	},
	{
		name: "Conversation AI",
		Icon: MessageSquareText
	},
	{
		name: "Marketing",
		Icon: Send
	},
	{
		name: "Website",
		Icon: Earth
	}
];
var ZERO = {
	x: 0,
	y: 0
};
/** Balanced orbit anchors: evenly spaced around the core, starting at the top. */
function anchor(i, radiusRatio) {
	const angle = -Math.PI / 2 + i * 2 * Math.PI / MODULES.length;
	return {
		ax: .5 + Math.cos(angle) * radiusRatio,
		ay: .5 + Math.sin(angle) * radiusRatio
	};
}
function HeroCore() {
	const wrapRef = (0, import_react.useRef)(null);
	const [size, setSize] = (0, import_react.useState)(0);
	const [offsets, setOffsets] = (0, import_react.useState)({});
	const [dragging, setDragging] = (0, import_react.useState)(null);
	const [settling, setSettling] = (0, import_react.useState)(null);
	const [activeName, setActiveName] = (0, import_react.useState)(null);
	const dragRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = wrapRef.current;
		if (!el) return;
		const ro = new ResizeObserver(() => setSize(el.clientWidth));
		ro.observe(el);
		setSize(el.clientWidth);
		return () => ro.disconnect();
	}, []);
	const radiusRatio = size && size < 480 ? .33 : .4;
	const coreRadius = Math.max(58, size * (size < 420 ? .15 : .155));
	const limit = Math.max(40, size * .16);
	const onPointerDown = (0, import_react.useCallback)((e, name) => {
		if (e.button !== void 0 && e.button !== 0 && e.pointerType === "mouse") return;
		e.currentTarget.setPointerCapture(e.pointerId);
		const cur = offsets[name] ?? ZERO;
		dragRef.current = {
			name,
			startX: e.clientX - cur.x,
			startY: e.clientY - cur.y
		};
		setDragging(name);
		setSettling(null);
		setActiveName(name);
	}, [offsets]);
	const onPointerMove = (0, import_react.useCallback)((e) => {
		const d = dragRef.current;
		if (!d) return;
		e.preventDefault();
		const clamp = (v) => Math.max(-limit, Math.min(limit, v));
		const next = {
			x: clamp(e.clientX - d.startX),
			y: clamp(e.clientY - d.startY)
		};
		setOffsets((o) => ({
			...o,
			[d.name]: next
		}));
	}, [limit]);
	const endDrag = (0, import_react.useCallback)(() => {
		const d = dragRef.current;
		if (!d) return;
		dragRef.current = null;
		setDragging(null);
		setSettling(d.name);
		setOffsets((o) => ({
			...o,
			[d.name]: ZERO
		}));
		window.setTimeout(() => setSettling((s) => s === d.name ? null : s), 700);
	}, []);
	const center = size / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative mx-auto aspect-square w-full max-w-[580px] touch-none select-none",
		"aria-label": "Connected LIEN PHAT AI platform visualization",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				"aria-hidden": "true",
				viewBox: `0 0 ${size || 600} ${size || 600}`,
				className: "absolute inset-0 size-full",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: center,
						cy: center,
						r: size * .29,
						fill: "none",
						stroke: "var(--border)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: center,
						cy: center,
						r: size * .4,
						fill: "none",
						stroke: "var(--border)",
						opacity: ".6"
					}),
					size > 0 && MODULES.map((m, i) => {
						const { ax, ay } = anchor(i, radiusRatio);
						const off = offsets[m.name] ?? ZERO;
						const nx = ax * size + off.x;
						const ny = ay * size + off.y;
						const dx = nx - center, dy = ny - center;
						const len = Math.hypot(dx, dy) || 1;
						const sx = center + dx / len * coreRadius;
						const sy = center + dy / len * coreRadius;
						const hot = activeName === m.name;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: sx,
							y1: sy,
							x2: nx,
							y2: ny,
							stroke: "var(--primary)",
							strokeWidth: hot ? 1.8 : 1,
							strokeLinecap: "round",
							opacity: hot ? .95 : .4,
							className: "flow-line"
						}, m.name);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-1/2 top-1/2 grid -translate-x-1/2 -translate-y-1/2 place-items-center overflow-hidden rounded-full border border-primary/50 text-center transition-shadow duration-500",
				style: {
					width: coreRadius * 2,
					height: coreRadius * 2,
					background: "color-mix(in oklab, var(--warm, #f7f7f2) 96%, var(--primary) 4%)",
					boxShadow: `0 0 ${activeName ? 110 : 80}px color-mix(in oklab, var(--primary) ${activeName ? 48 : 32}%, transparent)`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/lienphat-ai-core-approved.webp",
					alt: "LIENPHAT AI CORE Systems Online",
					className: "pointer-events-none size-[88%] object-contain"
				})
			}),
			MODULES.map((m, i) => {
				const { ax, ay } = anchor(i, radiusRatio);
				const off = offsets[m.name] ?? ZERO;
				const isDrag = dragging === m.name;
				const isSettling = settling === m.name;
				const hot = activeName === m.name;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${m.name} module — draggable`,
					onPointerDown: (e) => onPointerDown(e, m.name),
					onPointerMove,
					onPointerUp: endDrag,
					onPointerCancel: endDrag,
					onFocus: () => setActiveName(m.name),
					onBlur: () => setActiveName((n) => n === m.name ? null : n),
					onMouseEnter: () => !dragRef.current && setActiveName(m.name),
					onMouseLeave: () => !dragRef.current && setActiveName((n) => n === m.name ? null : n),
					className: `absolute z-10 flex items-center gap-2 rounded-md px-3 py-2 text-xs shadow-xl ${isDrag ? "cursor-grabbing" : "cursor-grab"} ${hot ? "border-primary/70 bg-surface-raised/90 text-foreground" : "glass"} ${isDrag ? "hero-node-drag" : isSettling ? "hero-node-snap" : "hero-node-idle"}`,
					style: {
						left: `${ax * 100}%`,
						top: `${ay * 100}%`,
						transform: `translate(calc(-50% + ${off.x}px), calc(-50% + ${off.y}px)) scale(${isDrag ? 1.07 : 1})`,
						animationDelay: `${i * -.65}s`,
						boxShadow: hot ? "0 0 26px color-mix(in oklab, var(--primary) 34%, transparent)" : void 0,
						borderWidth: 1
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `flex items-center gap-2 ${isDrag || isSettling ? "" : "hero-float"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.Icon, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "whitespace-nowrap",
							children: m.name
						})]
					})
				}, m.name);
			})
		]
	});
}
var intentLabels = {
	trial: {
		title: "Start your 30-day trial",
		qualifier: "What would you automate first?",
		options: [
			"Lead follow-up",
			"Appointments",
			"Customer communication",
			"Sales pipeline",
			"Not sure yet"
		]
	},
	strategy: {
		title: "Book an AI strategy call",
		qualifier: "What is your biggest growth bottleneck?",
		options: [
			"Missed leads",
			"Slow follow-up",
			"Too many tools",
			"Manual work",
			"Scaling operations"
		]
	},
	website: {
		title: "Build your website system",
		qualifier: "When would you like to launch?",
		options: [
			"Within 30 days",
			"1–3 months",
			"3–6 months",
			"Exploring options"
		]
	},
	growth: {
		title: "Build your growth system",
		qualifier: "What level of support do you need?",
		options: [
			"Full implementation",
			"Strategy + build",
			"Optimization",
			"Not sure yet"
		]
	},
	deploy: {
		title: "Deploy an AI employee",
		qualifier: "Which AI employee interests you most?",
		options: [
			"AI Voice Agent",
			"Appointment Setter",
			"Sales Assistant",
			"Customer Support",
			"Conversation AI"
		]
	},
	enterprise: {
		title: "Apply for enterprise",
		qualifier: "How many locations or teams do you support?",
		options: [
			"1–5",
			"6–20",
			"21–50",
			"51+"
		]
	}
};
function Index() {
	const [intent, setIntent] = (0, import_react.useState)(null);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const openLead = (next, source) => {
		track("cta_click", {
			intent: next,
			source
		});
		if (typeof window !== "undefined") sessionStorage.setItem("cta_source", source);
		setIntent(next);
	};
	(0, import_react.useEffect)(() => {
		track("page_view", { path: window.location.pathname });
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
				onOpen: openLead,
				mobileOpen,
				setMobileOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactStrip, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OneHub, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Framework, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AIEmployees, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessHub, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Automation, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Websites, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Marketing, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transformation, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoiCalculator, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pricing, { onOpen: openLead }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Industries, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Proof, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, { onOpen: openLead })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-3 bottom-3 z-40 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "premium",
					size: "lg",
					className: "w-full shadow-2xl",
					onClick: () => openLead("trial", "mobile_sticky"),
					children: ["Start 30-Day Trial ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDialog, {
				intent,
				onClose: () => setIntent(null)
			})
		]
	});
}
function Header({ onOpen, mobileOpen, setMobileOpen }) {
	const links = [
		["System", "#system"],
		["AI Employees", "#ai-employees"],
		["Solutions", "#solutions"],
		["Pricing", "#pricing"],
		["FAQ", "#faq"]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "fixed inset-x-0 top-0 z-40 border-b border-border bg-background/90 backdrop-blur-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-shell flex min-h-11 items-center justify-between gap-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-xs sm:text-sm",
						children: "Take Your System To The Next Level"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => onOpen("trial", "announcement_bar"),
						className: "min-h-8 rounded-md border border-primary-foreground/45 px-3 text-[10px] font-semibold transition-colors hover:bg-primary-foreground hover:text-primary",
						children: ["Start 30 Day Trial ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "· No Obligation. Cancel Anytime"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Primary navigation",
				className: "section-shell flex h-16 items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#top",
						className: "flex items-center gap-2 text-sm font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 shrink-0 place-items-center overflow-hidden rounded-full bg-warm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/lienphat-icon-approved.webp",
								alt: "",
								className: "size-[86%] object-contain"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["LIEN PHAT ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "AI"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-center gap-7 lg:flex",
						children: links.map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							className: "text-sm text-muted-foreground transition-colors hover:text-foreground",
							children: label
						}, href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "premium",
							onClick: () => onOpen("strategy", "nav"),
							children: ["Book AI Strategy Call ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"aria-label": mobileOpen ? "Close menu" : "Open menu",
						variant: "ghost",
						size: "icon",
						className: "min-h-11 min-w-11 md:hidden",
						onClick: () => setMobileOpen(!mobileOpen),
						children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
					})
				]
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border bg-background p-5 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-1",
					children: links.map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href,
						onClick: () => setMobileOpen(false),
						className: "min-h-11 py-3 text-lg",
						children: label
					}, href))
				})
			})
		]
	});
}
function SectionHeading({ eyebrow, title, copy, dark = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "reveal max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: dark ? "eyebrow text-cyan" : "eyebrow text-primary",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 text-balance text-4xl font-medium leading-[1.02] sm:text-6xl lg:text-7xl",
				children: title
			}),
			copy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-6 max-w-2xl text-lg leading-relaxed ${dark ? "text-muted-foreground" : "text-secondary-foreground/70"}`,
				children: copy
			})
		]
	});
}
function Hero({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "grain scan-grid relative min-h-[96svh] overflow-hidden border-b border-border pt-36 sm:pt-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_72%_45%,color-mix(in_oklab,var(--primary)_16%,transparent),transparent_35%),linear-gradient(180deg,transparent_55%,color-mix(in_oklab,var(--accent)_12%,transparent))]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell relative grid min-h-[calc(96svh-10rem)] items-center gap-14 pb-16 lg:grid-cols-[1.08fr_.92fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-4xl pt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-primary",
						children: "AI Infrastructure for modern business"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-6 text-balance text-[clamp(3rem,7vw,7.5rem)] font-semibold leading-[.91]",
						children: [
							"Launch Your Own ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "AI-Powered"
							}),
							" Business Operating System."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-7 max-w-2xl text-lg font-medium italic leading-relaxed text-muted-foreground",
						children: "Replace 10+ tools with a fully automated CRM, AI employees, marketing automation, and funnels."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-9 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "premium",
							size: "lg",
							onClick: () => onOpen("trial", "hero_primary"),
							children: ["Launch Your AI Business ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "luminous",
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#system",
								onClick: () => track("cta_click", { source: "hero_video" }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), " Watch The System"]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted-foreground",
						children: "Start your 30-day trial. No obligation. Cancel anytime."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-12 font-mono text-xs uppercase tracking-[.16em] text-foreground/60",
						children: ["Your business. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "Powered by AI."
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex w-full justify-center lg:-translate-y-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCore, {})
			})]
		})]
	});
}
function ImpactStrip() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-warm py-10 text-secondary-foreground sm:py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "section-shell grid grid-cols-2 gap-px overflow-hidden border border-secondary-foreground/10 bg-secondary-foreground/10 lg:grid-cols-4",
			children: [
				["1M+", "AI Voice Calls"],
				["7M+", "Leads Generated"],
				["2M+", "Appointments Won"],
				["$2.5B", "Sales Facilitated"]
			].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-warm px-4 py-7 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "block text-3xl font-bold sm:text-5xl",
					children: value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 block text-[10px] font-bold uppercase text-accent",
					children: label
				})]
			}, label))
		})
	});
}
function OneHub() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "system",
		className: "relative overflow-hidden py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "System consolidation",
				title: "STOP RUNNING YOUR BUSINESS THROUGH 15 DIFFERENT APPS.",
				copy: "One system. One login. One team helping you scale."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "reveal relative mt-20 min-h-[520px] overflow-hidden border-y border-border bg-surface/40 p-5 sm:p-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
					children: [
						"CRM",
						"SMS",
						"Email",
						"Funnels",
						"Calendar",
						"Reviews",
						"Payments",
						"Calls"
					].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass flex h-20 items-center justify-between rounded-md px-4 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[10px]",
								children: ["0", i + 1]
							}),
							x,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-destructive/70" })
						]
					}, x))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-6 bottom-10 mx-auto max-w-3xl border border-primary/50 bg-background/95 p-6 shadow-[0_0_80px_color-mix(in_oklab,var(--primary)_25%,transparent)] sm:p-9",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-between gap-5 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-cyan",
							children: "Unified & synchronized"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-2xl font-medium sm:text-4xl",
							children: "LIEN PHAT BUSINESS HUB"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 text-center font-mono text-[9px] text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1 LOGIN" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1 SOURCE" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1 SYSTEM" })
							]
						})]
					})
				})]
			})]
		})
	});
}
function Framework() {
	const stages = [
		[
			"CAPTURE",
			"Every opportunity enters one system.",
			[
				"Website",
				"Facebook",
				"Instagram",
				"Google",
				"Phone",
				"Forms"
			]
		],
		[
			"NURTURE",
			"AI responds while workflows move.",
			[
				"Instant reply",
				"SMS",
				"Email",
				"Qualification",
				"Follow-up"
			]
		],
		[
			"CLOSE",
			"Qualified prospects become appointments.",
			[
				"Pipeline",
				"Booking",
				"Sales tasks",
				"Notifications"
			]
		],
		[
			"RETAIN",
			"Relationships compound after the sale.",
			[
				"Reviews",
				"Campaigns",
				"Reactivation",
				"Support"
			]
		],
		[
			"SCALE",
			"Infrastructure grows without fragmentation.",
			[
				"Teams",
				"Locations",
				"Volume",
				"Visibility"
			]
		]
	];
	const [active, setActive] = (0, import_react.useState)(0);
	const currentStage = stages[active] ?? stages[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-warm py-28 text-secondary-foreground sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				dark: false,
				eyebrow: "The growth loop",
				title: "One operating system. Every stage of the customer journey."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 grid gap-10 lg:grid-cols-[.8fr_1.2fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: stages.map(([title, copy], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActive(i),
						className: `group min-h-11 w-full border-l-2 p-5 text-left transition-all ${active === i ? "border-primary bg-secondary-foreground" : "border-warm/15 bg-background hover:border-primary"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs text-warm/85",
								children: ["0", i + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "ml-5 text-xl text-warm",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 block text-sm text-warm/80",
								children: copy
							})
						]
					}, title))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-24 h-fit min-h-[470px] overflow-hidden bg-secondary-foreground p-6 shadow-2xl sm:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-warm/15 pb-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs text-warm",
								children: ["LIVE JOURNEY / ", currentStage[0]]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 animate-pulse rounded-full bg-primary" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-4 sm:grid-cols-2",
							children: currentStage[2].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-h-24 items-center gap-4 border border-warm/10 bg-warm/5 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-9 place-items-center rounded-full bg-primary text-primary-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-[9px] text-primary",
									children: ["STEP ", i + 1]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-medium text-warm",
									children: x
								})] })]
							}, x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 h-1 overflow-hidden bg-warm/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-gradient-to-r from-primary via-accent to-primary transition-all duration-700",
								style: { width: `${(active + 1) * 20}%` }
							})
						})
					]
				})]
			})]
		})
	});
}
var employees = [
	{
		name: "AI Voice Agent",
		icon: MicVocal,
		label: "VOICE / INBOUND",
		steps: [
			"Incoming Call",
			"AI Answering",
			"Lead Qualified",
			"Appointment Booked",
			"CRM Updated",
			"Team Notified"
		]
	},
	{
		name: "Conversation AI",
		icon: MessageSquareText,
		label: "CHAT / 24-7",
		steps: [
			"New website chat",
			"Intent detected",
			"Needs clarified",
			"Time selected",
			"Booking confirmed"
		]
	},
	{
		name: "AI Sales Assistant",
		icon: Zap,
		label: "SALES / PIPELINE",
		steps: [
			"Lead scored",
			"Follow-up sent",
			"Objection handled",
			"Opportunity advanced"
		]
	},
	{
		name: "AI Customer Support",
		icon: Bot,
		label: "SUPPORT / ALWAYS ON",
		steps: [
			"Question received",
			"Context reviewed",
			"Answer delivered",
			"Record updated"
		]
	},
	{
		name: "AI Appointment Setter",
		icon: CalendarDays,
		label: "BOOKING / AUTOMATED",
		steps: [
			"Interest detected",
			"Calendar checked",
			"Slot reserved",
			"Reminder queued"
		]
	}
];
function AIEmployees({ onOpen }) {
	const ref = (0, import_react.useRef)(null);
	const scroll = (dir) => ref.current?.scrollBy({
		left: dir * 410,
		behavior: "smooth"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "ai-employees",
		className: "overflow-hidden py-28 sm:py-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "section-shell",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Digital workforce",
					title: "Put AI To Work Inside Your Business."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden gap-2 sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"aria-label": "Previous AI employee",
						variant: "luminous",
						size: "icon",
						onClick: () => scroll(-1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						"aria-label": "Next AI employee",
						variant: "luminous",
						size: "icon",
						onClick: () => scroll(1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			tabIndex: 0,
			"aria-label": "AI employee product demos",
			className: "mt-14 flex snap-x snap-mandatory gap-5 overflow-x-auto px-[max(1rem,calc((100vw-80rem)/2))] pb-7 [scrollbar-width:none]",
			children: employees.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "glass min-w-[85vw] snap-center overflow-hidden rounded-lg p-5 sm:min-w-[390px] sm:p-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow text-cyan",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "text-cyan" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-8 text-2xl font-medium",
						children: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 space-y-2",
						children: item.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 border border-border bg-background/70 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${i <= 2 ? "bg-cyan shadow-[0_0_12px_var(--cyan)]" : "bg-muted-foreground/30"}` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 text-sm",
									children: step
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[9px] text-muted-foreground",
									children: String(i + 1).padStart(2, "0")
								})
							]
						}, step))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: idx === 0 ? "premium" : "luminous",
						className: "mt-7 w-full",
						onClick: () => onOpen("deploy", `ai_employee_${item.name}`),
						children: [
							"Deploy ",
							item.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})
						]
					})
				]
			}, item.name))
		})]
	});
}
function Automation() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Intelligent orchestration",
				title: "Your Business Should Work Even When You Aren’t Working."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "reveal relative mt-16 overflow-hidden border-y border-border py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-10 right-10 top-1/2 hidden h-px bg-gradient-to-r from-primary via-accent to-primary lg:block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative grid gap-4 sm:grid-cols-2 lg:grid-cols-8",
					children: [
						"Lead Captured",
						"AI Qualification",
						"SMS",
						"Email",
						"Calendar Booking",
						"CRM Update",
						"Reminder",
						"Sales Notification"
					].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass group min-h-28 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[9px] text-cyan",
								children: ["NODE ", String(i + 1).padStart(2, "0")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-sm font-medium",
								children: x
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-4 block h-px w-8 bg-primary transition-all group-hover:w-full" })
						]
					}, x))
				})]
			})]
		})
	});
}
function Websites({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "solutions",
		className: "bg-warm py-28 text-secondary-foreground sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell grid items-center gap-16 lg:grid-cols-[.9fr_1.1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				dark: false,
				eyebrow: "Done-for-you web systems",
				title: "Your Website Should Be More Than An Online Brochure.",
				copy: "It should capture, qualify, nurture and convert."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "premium",
				size: "lg",
				className: "mt-9",
				onClick: () => onOpen("website", "website_section"),
				children: ["Build My Website System ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-[530px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-0 top-12 w-[84%] border border-secondary-foreground/15 bg-background p-3 text-foreground shadow-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1.5 border-b border-border pb-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-destructive" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-cyan" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid min-h-[350px] place-items-center bg-[radial-gradient(circle_at_60%_20%,color-mix(in_oklab,var(--primary)_30%,transparent),transparent_35%)] p-8 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow text-cyan",
								children: "Conversion engine"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-4xl font-medium",
								children: "Every visit becomes a journey."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-7 inline-flex bg-primary px-5 py-3 text-sm",
								children: "Book a consultation"
							})
						] })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute bottom-0 right-0 w-52 border border-secondary-foreground/15 bg-warm p-5 shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[9px] text-primary",
						children: "CONNECTED SYSTEMS"
					}), [
						"CRM",
						"AI Chat",
						"Calendars",
						"Forms",
						"Funnels",
						"Automation"
					].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center justify-between border-b border-secondary-foreground/10 pb-2 text-xs",
						children: [x, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-primary" })]
					}, x))]
				})]
			})]
		})
	});
}
function Marketing({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-end gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Growth infrastructure",
					title: "Turn Marketing Into A System.",
					copy: "Premium done-for-you growth implementation, connected to the same customer intelligence layer."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "luminous",
						size: "lg",
						onClick: () => onOpen("growth", "marketing_section"),
						children: ["Explore Growth Implementation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal mt-16 grid grid-cols-2 gap-px overflow-hidden bg-border sm:grid-cols-3 lg:grid-cols-5",
				children: [
					"Social Media",
					"Email",
					"SMS",
					"Funnels",
					"Landing Pages",
					"Advertising",
					"Database Reactivation",
					"Reviews",
					"Campaigns",
					"AI Follow-Up"
				].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group min-h-40 bg-background p-5 transition-colors hover:bg-surface-raised",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[9px] text-muted-foreground",
						children: ["M/", String(i + 1).padStart(2, "0")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-12 text-sm group-hover:text-cyan",
						children: x
					})]
				}, x))
			})]
		})
	});
}
function Transformation() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-surface py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "The transformation",
				title: "From fragmented operations to compounding intelligence."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border bg-background p-6 sm:p-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-destructive",
						children: "Before LIEN PHAT AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-7 grid gap-2 sm:grid-cols-2",
						children: [
							"15 apps",
							"Missed calls",
							"Manual follow-up",
							"Scattered data",
							"Multiple vendors",
							"Lost leads",
							"Slow response",
							"No visibility"
						].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex min-h-12 items-center gap-3 border border-border p-3 text-sm text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 text-destructive" }), x]
						}, x))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-primary/50 bg-background p-6 shadow-[var(--shadow-glow)] sm:p-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-cyan",
						children: "After LIEN PHAT AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-7 grid gap-2 sm:grid-cols-2",
						children: [
							"One ecosystem",
							"24/7 AI",
							"Automated follow-up",
							"Centralized CRM",
							"Connected communication",
							"Automated scheduling",
							"Pipeline visibility",
							"Scalable infrastructure"
						].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex min-h-12 items-center gap-3 border border-border p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-cyan" }), x]
						}, x))
					})]
				})]
			})]
		})
	});
}
function RoiCalculator({ onOpen }) {
	const [leads, setLeads] = (0, import_react.useState)(100);
	const [value, setValue] = (0, import_react.useState)(2500);
	const [close, setClose] = (0, import_react.useState)(20);
	const [lost, setLost] = (0, import_react.useState)(35);
	const calc = (0, import_react.useMemo)(() => {
		const opp = leads * lost / 100;
		return {
			opp,
			revenue: opp * close / 100 * value
		};
	}, [
		leads,
		value,
		close,
		lost
	]);
	const money = new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Opportunity model",
				title: "What is slow follow-up costing you?",
				copy: "Adjust the assumptions to estimate the opportunity inside your current lead flow."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "reveal mt-16 grid overflow-hidden border border-border lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-surface p-6 sm:p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-6",
						children: [
							[
								"Monthly leads",
								leads,
								setLeads,
								1,
								1e4
							],
							[
								"Average customer value",
								value,
								setValue,
								1,
								1e5
							],
							[
								"Current close rate (%)",
								close,
								setClose,
								0,
								100
							],
							[
								"Leads currently lost (%)",
								lost,
								setLost,
								0,
								100
							]
						].map(([label, val, set, min, max]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: label,
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-sm text-cyan",
								children: label.includes("value") ? money.format(val) : val.toLocaleString()
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: label,
							type: "range",
							min,
							max,
							step: label.includes("value") ? 100 : 1,
							value: val,
							onChange: (e) => set(Number(e.target.value)),
							className: "h-11 w-full accent-[var(--primary)]"
						})] }, label))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between bg-warm p-6 text-secondary-foreground sm:p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-primary",
							children: "Estimated monthly opportunity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-5xl font-medium sm:text-7xl",
							children: money.format(calc.revenue)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-9 grid grid-cols-2 gap-5 border-t border-secondary-foreground/15 pt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-secondary-foreground/60",
								children: "Revenue currently at risk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-2xl",
								children: money.format(calc.revenue)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-secondary-foreground/60",
								children: "Recoverable opportunities"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-2xl",
								children: Math.round(calc.opp)
							})] })]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 text-xs leading-relaxed text-secondary-foreground/55",
						children: "Illustrative estimate only, based on your inputs. Results are not guaranteed and depend on execution, market conditions, and lead quality."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "premium",
						size: "lg",
						className: "mt-5 w-full",
						onClick: () => {
							track("calculator_completion", {
								leads,
								value,
								close,
								lost,
								estimated: calc.revenue
							});
							onOpen("strategy", "roi_calculator");
						},
						children: ["Review My Opportunity ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})] })]
				})]
			})]
		})
	});
}
var plans = [
	{
		name: "LIEN PHAT BUSINESS HUB",
		price: "Starting at $97/month",
		features: [
			"CRM",
			"Automation",
			"Communication",
			"Scheduling",
			"Funnels",
			"Customer Management"
		],
		cta: "Start Trial",
		intent: "trial"
	},
	{
		name: "AI EMPLOYEE SYSTEM",
		price: "Starting at $197–$497/month",
		features: [
			"AI Voice",
			"Conversation AI",
			"Lead Qualification",
			"Appointment Booking",
			"Automation"
		],
		cta: "Deploy AI",
		intent: "deploy",
		featured: true
	},
	{
		name: "AI WEBSITE LAUNCH",
		price: "Starting at approximately $1,500",
		features: [
			"Professional Website",
			"Domain Integration",
			"CRM",
			"Lead Capture",
			"Calendars",
			"Basic Automation",
			"AI Chat"
		],
		cta: "Build My Website",
		intent: "website"
	},
	{
		name: "AI GROWTH IMPLEMENTATION",
		price: "Starting around $3,000",
		features: [
			"Website",
			"CRM",
			"AI",
			"Automation",
			"Funnels",
			"Marketing",
			"Campaigns",
			"Lead Nurture"
		],
		cta: "Build My Growth System",
		intent: "growth",
		featured: true
	},
	{
		name: "ENTERPRISE",
		price: "Custom pricing",
		features: [
			"Advanced AI infrastructure",
			"Multi-location systems",
			"Custom workflows",
			"Dedicated implementation"
		],
		cta: "Apply To Qualify",
		intent: "enterprise"
	}
];
function Pricing({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "pricing",
		className: "border-y border-border bg-surface py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Choose your path",
					title: "Software when you want control. Implementation when you want velocity."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-16 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
					children: plans.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `flex min-h-[450px] flex-col border p-6 sm:p-8 ${p.featured ? "border-primary bg-background shadow-[var(--shadow-glow)]" : "border-border bg-background"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "eyebrow text-cyan",
									children: i < 2 ? "Software" : "Done for you"
								}), p.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4 text-cyan" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-7 text-xl font-medium",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted-foreground",
								children: p.price
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-8 flex-1 space-y-3",
								children: p.features.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2 text-sm text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-cyan" }), x]
								}, x))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: p.featured ? "premium" : "luminous",
								size: "lg",
								className: "mt-8 w-full",
								onClick: () => {
									track("pricing_cta_click", { plan: p.name });
									onOpen(p.intent, `pricing_${p.name}`);
								},
								children: [p.cta, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						]
					}, p.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-3xl text-xs leading-relaxed text-muted-foreground",
					children: "Starting and approximate prices are planning guides, not final quotes. Actual pricing depends on scope, usage, integrations, implementation requirements, and ongoing support."
				})
			]
		})
	});
}
function Industries() {
	const industries = [
		"Real Estate",
		"Multifamily",
		"Private Equity",
		"Financial Services",
		"Tax Advisory",
		"Healthcare",
		"Medical Practices",
		"Dental",
		"Home Services",
		"HVAC",
		"Roofing",
		"Law Firms",
		"Insurance",
		"Consulting",
		"Professional Services",
		"Gyms",
		"Restaurants",
		"Local Businesses",
		"Multi-location Companies"
	];
	const [active, setActive] = (0, import_react.useState)(industries[0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Built around your operation",
				title: "Infrastructure that adapts to the way your business moves."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid gap-6 lg:grid-cols-[1fr_.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: industries.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setActive(x),
						className: `min-h-11 border px-4 py-2 text-sm transition-colors ${active === x ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface text-muted-foreground hover:text-foreground"}`,
						children: x
					}, x))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass min-h-72 p-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "text-cyan" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow mt-9 text-cyan",
							children: "Selected industry"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-3xl",
							children: active
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm leading-relaxed text-muted-foreground",
							children: "Connect lead capture, rapid response, scheduling, customer communication, pipeline visibility, and automation around your operating model."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 flex items-center gap-2 font-mono text-[10px] text-cyan",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 animate-pulse rounded-full bg-cyan" }), " SYSTEM MODEL READY"]
						})
					]
				})]
			})]
		})
	});
}
function Proof() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-warm py-28 text-secondary-foreground sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				dark: false,
				eyebrow: "Proof, without fiction",
				title: "Real outcomes belong here. Nothing invented.",
				copy: "This area is intentionally reserved for reviewed, permissioned customer evidence."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid gap-4 md:grid-cols-3",
				children: [
					"Verified case study coming here",
					"Approved customer quote coming here",
					"Validated implementation result coming here"
				].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "border border-secondary-foreground/15 bg-background p-7 text-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[9px] text-cyan",
							children: ["VERIFIED CONTENT ONLY / 0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-20 text-xl",
							children: x
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted-foreground",
							children: "Reserved for customer, challenge, implementation, measurable result, and verification date."
						})
					]
				}, x))
			})]
		})
	});
}
var faqs = [
	["What does LIEN PHAT AI do?", "We connect CRM, AI employees, communication, sales, marketing, websites, scheduling, payments, and workflows into one operating system."],
	["What is an AI Voice Agent?", "An AI Voice Agent can answer calls, handle routine conversations, qualify leads, book appointments, and update connected systems based on your approved workflow."],
	["How does Conversation AI work?", "It responds across supported messaging channels, gathers context, answers approved questions, qualifies opportunities, and moves conversations toward the next action."],
	["Do you implement the system for us?", "Yes. You can choose software access, focused implementation, or a broader done-for-you growth system."],
	["Can it connect with our current tools?", "Integration scope depends on your current systems and their available connections. We assess this before recommending an implementation."],
	["Do you provide marketing services?", "Yes. Growth implementation can include campaigns, funnels, database reactivation, follow-up systems, and connected marketing operations."],
	["Can you build our website?", "Yes. AI Website Launch combines a professional site with lead capture, CRM, calendars, automation, and optional AI chat."],
	["Will AI replace our staff?", "The goal is to automate repetitive work and support your team. The right operating model keeps people in control of consequential decisions."],
	["How much does it cost?", "Software starts at the prices shown above. Implementation is scoped around requirements, integrations, usage, and support."],
	["Is training and support included?", "Training and support are matched to the selected plan and implementation scope, and are confirmed before launch."]
];
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "py-28 sm:py-40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell grid gap-14 lg:grid-cols-[.75fr_1.25fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Clarity before commitment",
				title: "Questions, answered."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
				type: "single",
				collapsible: true,
				className: "border-t border-border",
				children: faqs.map(([q, a], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
					value: `faq-${i}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
						className: "min-h-16 text-base hover:no-underline",
						children: q
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
						className: "max-w-2xl pb-6 text-base leading-relaxed text-muted-foreground",
						children: a
					})]
				}, q))
			})]
		})
	});
}
function FinalCta({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grain scan-grid relative grid min-h-[90svh] place-items-center overflow-hidden border-y border-border py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_50%_55%,color-mix(in_oklab,var(--primary)_24%,transparent),transparent_38%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow text-cyan",
					children: "The next operating model"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mx-auto mt-7 max-w-6xl text-balance text-5xl font-semibold leading-[.95] sm:text-7xl lg:text-9xl",
					children: ["Your Business Doesn’t Need More Apps. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: "It Needs A Better System."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-8 max-w-2xl text-lg text-muted-foreground",
					children: "Build the infrastructure that captures opportunities, automates repetitive work and prepares your company to scale."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-col justify-center gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "premium",
						size: "lg",
						onClick: () => onOpen("growth", "final_primary"),
						children: ["Build My AI Business ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "luminous",
						size: "lg",
						onClick: () => onOpen("trial", "final_secondary"),
						children: "Start 30-Day Trial"
					})]
				})
			]
		})]
	});
}
function LeadDialog({ intent, onClose }) {
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [started, setStarted] = (0, import_react.useState)(false);
	const current = intent ? intentLabels[intent] : null;
	(0, import_react.useEffect)(() => {
		if (intent) {
			setStatus("idle");
			setStarted(false);
			track("form_open", { intent });
		}
	}, [intent]);
	async function submit(e) {
		e.preventDefault();
		if (!intent) return;
		setStatus("loading");
		track("form_submit", { intent });
		const fd = new FormData(e.currentTarget);
		const params = new URLSearchParams(window.location.search);
		const { error } = await supabase.from("leads").insert({
			first_name: String(fd.get("first_name")),
			last_name: String(fd.get("last_name")),
			email: String(fd.get("email")),
			phone: String(fd.get("phone")),
			company: String(fd.get("company")),
			request_type: intent,
			qualification: String(fd.get("qualification")),
			consent: fd.get("consent") === "on",
			utm_source: params.get("utm_source"),
			utm_medium: params.get("utm_medium"),
			utm_campaign: params.get("utm_campaign"),
			utm_content: params.get("utm_content"),
			utm_term: params.get("utm_term"),
			referrer: document.referrer || null,
			cta_source: String(sessionStorage.getItem("cta_source") || intent),
			landing_page: window.location.href
		});
		if (error) {
			setStatus("error");
			return;
		}
		setStatus("success");
		track("form_success", { intent });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(intent),
		onOpenChange: (v) => {
			if (!v) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "max-h-[92svh] overflow-y-auto border-border bg-surface p-6 sm:max-w-2xl sm:p-8",
			children: status === "success" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-12 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-auto grid size-14 place-items-center rounded-full bg-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "mt-6 text-3xl",
						children: "You’re on the way."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mx-auto mt-3 max-w-md text-base",
						children: "Your request has been received. The LIEN PHAT AI team can now review your goals and next best step."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-7",
						variant: "luminous",
						onClick: onClose,
						children: "Close"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow text-cyan",
					children: "Start the conversation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "mt-2 text-2xl sm:text-3xl",
					children: current?.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Tell us where you are now. We’ll use this to prepare the right next step." })
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				onFocus: () => {
					if (!started) {
						setStarted(true);
						track("form_start", { intent });
					}
				},
				className: "mt-3 space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "first_name",
								label: "First name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "last_name",
								label: "Last name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "email",
								label: "Work email",
								type: "email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "phone",
								label: "Phone",
								type: "tel"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "company",
									label: "Business / company"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "qualification",
									children: current?.qualifier
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "qualification",
									name: "qualification",
									required: true,
									defaultValue: "",
									className: "mt-2 min-h-11 w-full rounded-md border border-input bg-background px-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										disabled: true,
										children: "Select one"
									}), current?.options.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: x }, x))]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							id: "consent",
							name: "consent",
							required: true,
							className: "mt-0.5"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "consent",
							className: "text-xs font-normal leading-relaxed text-muted-foreground",
							children: "I agree to be contacted about this request by phone, email, or text. Consent is not a condition of purchase. Message and data rates may apply. [Privacy and terms links to be added before launch.]"
						})]
					}),
					status === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: "Your request could not be sent. Please review your information and try again."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						variant: "premium",
						size: "lg",
						className: "w-full",
						disabled: status === "loading",
						children: [status === "loading" ? "Sending securely…" : "Submit Request", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				]
			})] })
		})
	});
}
function Field({ id, label, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		htmlFor: id,
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		id,
		name: id,
		type,
		required: true,
		maxLength: id === "email" ? 320 : 200,
		autoComplete: id === "first_name" ? "given-name" : id === "last_name" ? "family-name" : id === "company" ? "organization" : id,
		className: "mt-2 min-h-11 bg-background text-base sm:text-sm"
	})] });
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "pb-24 pt-14 md:pb-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-shell flex flex-col justify-between gap-8 border-t border-border pt-8 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-semibold",
				children: ["LIEN PHAT ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-cyan",
					children: "AI"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-xs text-muted-foreground",
				children: "AI-powered business infrastructure for modern companies."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" LIEN PHAT AI. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "Privacy • Terms • Accessibility"
				})]
			})]
		})
	});
}
//#endregion
export { Index as component };

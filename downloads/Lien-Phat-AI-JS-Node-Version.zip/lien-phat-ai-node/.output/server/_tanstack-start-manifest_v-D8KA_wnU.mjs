//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8KA_wnU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/scratch/db70505c5136/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DHaSwbpM.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DHaSwbpM.js"
		} }]
	},
	"/": {
		filePath: "/workspace/scratch/db70505c5136/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BZaKv_ny.js"]
	}
} });
//#endregion
export { tsrStartManifest };

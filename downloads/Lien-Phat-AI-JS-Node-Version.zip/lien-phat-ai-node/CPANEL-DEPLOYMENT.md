# LIEN PHAT AI — Hosting.com cPanel Node.js deployment

This package contains the original React/TanStack Start project and a tested
Nitro Node.js production build. It is not a WordPress theme.

## Required Hosting.com feature

In cPanel, open **Software** and confirm that **Setup Node.js App** exists.
If it is not present, the current plan cannot use this deployment package.
Keep the project on Vercel or ask Hosting.com to move the account to a plan
with the cPanel Node.js Selector. Do not upload this ZIP through WordPress.

## Upload the package

1. Keep the existing WordPress site in place until the Node site has been tested.
2. In cPanel File Manager, open your home directory, not `public_html`.
3. Create an `apps` directory if one does not already exist.
4. Upload `Lien-Phat-AI-cPanel-Node-v1.0.0.zip` into `apps` and extract it.
5. Confirm the application root is:
   `/home/CPANEL_USERNAME/apps/lien-phat-ai-node`
6. Confirm `package.json`, `app.js`, and `.output` are directly inside that folder.

## Create the Node.js application

Open **cPanel > Software > Setup Node.js App > Create Application** and use:

- Node.js version: **22** (Node 20.19 or newer is required)
- Application mode: **Production**
- Application root: `apps/lien-phat-ai-node`
- Application URL: select the production domain and use `/` for the root URL
- Application startup file: `app.js`

Add these environment variables in the application screen:

- `NODE_ENV` = `production`
- `HOST` = `0.0.0.0`
- `SUPABASE_URL` = the value used by the current Vercel project
- `SUPABASE_PUBLISHABLE_KEY` = the value used by the current Vercel project
- `VITE_SUPABASE_URL` = the same Supabase URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` = the same publishable key

Never put a Supabase service-role key or another private secret in a `VITE_`
variable. `VITE_` values are intentionally included in browser code.

The included `.output` build lets the homepage start immediately. Rebuild it
after adding the four Supabase URL/publishable-key values so lead forms receive
the correct browser configuration.

## Install and rebuild

Click **Run NPM Install** in the Node.js application screen. Then open cPanel
Terminal or connect with SSH. Copy the virtual-environment activation command
shown at the top of the Node.js application page, then run:

```sh
cd ~/apps/lien-phat-ai-node
npm ci --include=dev
npm run build:cpanel
```

Return to **Setup Node.js App** and click **Restart**. Open the application URL
and test the homepage, mobile menu, calculator, modal, and one test lead.

## Domain cutover

The Node.js application root stays outside `public_html`; cPanel routes the
selected domain to it. Do not delete WordPress until the Node application works
over HTTPS on the final domain. Keep existing MX and email-related TXT records.

If the domain currently points to Vercel or Cloudflare, update only the web A or
CNAME records after Hosting.com provides the correct server destination. Leave
mail records unchanged. If Cloudflare proxying causes an error during setup,
temporarily use DNS-only mode until Hosting.com SSL and routing are working.

## Updating later

For future GitHub updates, replace the source files, then run:

```sh
npm ci --include=dev
npm run build:cpanel
```

Restart the application in cPanel after every production build.

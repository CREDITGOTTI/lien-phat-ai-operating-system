<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="lp-section" style="padding-top:160px;min-height:70vh">
    <div class="lp-shell">
        <p class="lp-kicker"><?php esc_html_e('404', 'lien-phat-ai'); ?></p>
        <h1><?php esc_html_e('Page not found', 'lien-phat-ai'); ?></h1>
        <p class="lp-copy"><?php esc_html_e('The page you requested could not be found.', 'lien-phat-ai'); ?></p>
        <a class="lp-btn lp-btn-primary" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Return home', 'lien-phat-ai'); ?></a>
    </div>
</main>
<?php get_footer(); ?>

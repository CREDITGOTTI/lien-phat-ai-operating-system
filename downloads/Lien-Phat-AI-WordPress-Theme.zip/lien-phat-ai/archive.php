<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="lp-section" style="padding-top:160px">
    <div class="lp-shell">
        <h1><?php the_archive_title(); ?></h1>
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('lp-card'); ?> style="padding:30px;margin-bottom:20px">
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <?php the_excerpt(); ?>
            </article>
        <?php endwhile; the_posts_navigation(); else : ?>
            <p><?php esc_html_e('Nothing found.', 'lien-phat-ai'); ?></p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>

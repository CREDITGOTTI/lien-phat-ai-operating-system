(()=>{'use strict';
const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>[...c.querySelectorAll(s)];
const menu=$('.lp-menu'),mobile=$('.lp-mobile');
menu?.addEventListener('click',()=>{const open=mobile.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.textContent=open?'×':'☰'});
$$('.lp-mobile a').forEach(a=>a.addEventListener('click',()=>{mobile.classList.remove('open');menu.textContent='☰';menu.setAttribute('aria-expanded','false')}));

const stageItems=$('#lp-stage-items'),stageTitle=$('#lp-stage-title'),stageProgress=$('#lp-stage-progress');
function showStage(btn,index){$$('.lp-stage').forEach(x=>x.classList.remove('active'));btn.classList.add('active');stageTitle.textContent=btn.dataset.title;stageItems.innerHTML=(btn.dataset.items||'').split('|').map((x,i)=>`<div class="lp-step"><span class="lp-check">✓</span><div><small>STEP ${i+1}</small><br>${x}</div></div>`).join('');stageProgress.style.width=`${(index+1)*20}%`}
$$('.lp-stage').forEach((b,i)=>b.addEventListener('click',()=>showStage(b,i)));if($('.lp-stage'))showStage($('.lp-stage'),0);

$$('.lp-hub-tab').forEach(btn=>btn.addEventListener('click',()=>{$$('.lp-hub-tab').forEach(x=>x.classList.remove('active'));$$('.lp-hub-panel').forEach(x=>x.classList.remove('active'));btn.classList.add('active');$('#hub-'+CSS.escape(btn.dataset.hub))?.classList.add('active')}));
$$('.lp-industry').forEach(btn=>btn.addEventListener('click',()=>{$$('.lp-industry').forEach(x=>x.classList.remove('active'));btn.classList.add('active');$('#lp-industry-title').textContent=btn.textContent}));

const money=new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0});
function calc(){const vals={};$$('[data-roi]').forEach(i=>{vals[i.dataset.roi]=Number(i.value);const out=$(`[data-output="${i.dataset.roi}"]`);out.textContent=i.dataset.roi==='value'?money.format(vals[i.dataset.roi]):vals[i.dataset.roi].toLocaleString()});const opp=vals.leads*vals.lost/100,revenue=opp*vals.close/100*vals.value;$('#lp-roi-amount').textContent=money.format(revenue);$('#lp-roi-opps').textContent=Math.round(opp).toLocaleString()}
$$('[data-roi]').forEach(i=>i.addEventListener('input',calc));calc();

const intents={
 trial:['Start your 30-day trial','What would you automate first?',['Lead follow-up','Appointments','Customer communication','Sales pipeline','Not sure yet']],
 strategy:['Book an AI strategy call','What is your biggest growth bottleneck?',['Missed leads','Slow follow-up','Too many tools','Manual work','Scaling operations']],
 website:['Build your website system','When would you like to launch?',['Within 30 days','1–3 months','3–6 months','Exploring options']],
 growth:['Build your growth system','What level of support do you need?',['Full implementation','Strategy + build','Optimization','Not sure yet']],
 deploy:['Deploy an AI employee','Which AI employee interests you most?',['AI Voice Agent','Appointment Setter','Sales Assistant','Customer Support','Conversation AI']],
 enterprise:['Apply for enterprise','How many locations or teams do you support?',['1–5','6–20','21–50','51+']]
};
const modal=$('#lp-lead-modal'),form=$('#lp-lead-form'),notice=$('#lp-form-notice'),focusable=()=>$$('button,input,select,a',modal).filter(x=>!x.disabled);
function openModal(intent,source){const data=intents[intent]||intents.trial;$('#lp-form-title').textContent=data[0];$('#lp-qualifier-label').textContent=data[1];form.request_type.value=intent;form.cta_source.value=source||intent;form.landing_page.value=location.href;form.nonce.value=window.lpaiConfig?.nonce||'';form.qualification.innerHTML='<option value="">Select one</option>'+data[2].map(x=>`<option>${x}</option>`).join('');notice.style.display='none';modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';setTimeout(()=>$('.lp-close',modal).focus(),30)}
function closeModal(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');document.body.style.overflow=''}
$$('[data-lead]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.lead,b.dataset.source)));
$('.lp-close',modal)?.addEventListener('click',closeModal);modal?.addEventListener('click',e=>{if(e.target===modal)closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))closeModal();if(e.key==='Tab'&&modal.classList.contains('open')){const fs=focusable(),first=fs[0],last=fs[fs.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
form?.addEventListener('submit',async e=>{e.preventDefault();const button=$('button[type="submit"]',form),original=button.textContent;button.disabled=true;button.textContent='Sending securely…';const params=new URLSearchParams(location.search);['utm_source','utm_medium','utm_campaign'].forEach(k=>{const v=params.get(k);if(v){const i=document.createElement('input');i.type='hidden';i.name=k;i.value=v;form.appendChild(i)}});try{const res=await fetch(window.lpaiConfig.ajaxUrl,{method:'POST',body:new FormData(form),credentials:'same-origin'}),json=await res.json();if(!res.ok||!json.success)throw new Error(json.data?.message||'Unable to send request.');notice.textContent=json.data.message;notice.style.display='block';form.reset();setTimeout(closeModal,2600)}catch(err){notice.textContent=err.message||'Please try again.';notice.style.display='block';notice.style.borderColor='var(--danger)';notice.style.color='var(--danger)'}finally{button.disabled=false;button.textContent=original}});

if('IntersectionObserver'in window){const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.animate([{opacity:0,transform:'translateY(25px)'},{opacity:1,transform:'none'}],{duration:650,easing:'cubic-bezier(.2,.7,.2,1)',fill:'both'});io.unobserve(e.target)}}),{threshold:.12});$$('.lp-title,.lp-card,.lp-plan').forEach(el=>io.observe(el))}
})();

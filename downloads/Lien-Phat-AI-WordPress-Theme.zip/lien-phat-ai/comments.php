<?php
if (!defined('ABSPATH')) exit;

if (post_password_required()) {
    return;
}
?>
<section id="comments" class="lp-comments">
    <?php if (have_comments()) : ?>
        <h2><?php esc_html_e('Comments', 'lien-phat-ai'); ?></h2>
        <ol class="comment-list">
            <?php wp_list_comments(array('style' => 'ol', 'short_ping' => true)); ?>
        </ol>
        <?php the_comments_navigation(); ?>
    <?php endif; ?>

    <?php if (!comments_open() && get_comments_number()) : ?>
        <p><?php esc_html_e('Comments are closed.', 'lien-phat-ai'); ?></p>
    <?php endif; ?>

    <?php comment_form(); ?>
</section>

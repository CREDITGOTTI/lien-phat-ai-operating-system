<?php
if (!defined('ABSPATH')) exit;

define('LPAI_VERSION', '1.2.0');

function lpai_setup() {
    load_theme_textdomain('lien-phat-ai', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
}
add_action('after_setup_theme', 'lpai_setup');

function lpai_assets() {
    wp_enqueue_style('lpai-font', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;0,800;1,600&display=swap', array(), null);
    wp_enqueue_style('lpai-theme', get_stylesheet_uri(), array('lpai-font'), LPAI_VERSION);
    wp_enqueue_script('lpai-theme', get_template_directory_uri() . '/assets/js/theme.js', array(), LPAI_VERSION, true);
    wp_localize_script('lpai-theme', 'lpaiConfig', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('lpai_lead'),
    ));
}
add_action('wp_enqueue_scripts', 'lpai_assets');

function lpai_register_leads() {
    register_post_type('lpai_lead', array(
        'labels' => array('name' => 'Lien Phat Leads', 'singular_name' => 'Lead'),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-businessperson',
        'supports' => array('title','custom-fields'),
        'capability_type' => 'post',
    ));
}
add_action('init', 'lpai_register_leads');

function lpai_clean($key) { return isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : ''; }
function lpai_submit_lead() {
    check_ajax_referer('lpai_lead', 'nonce');
    if (!empty($_POST['website'])) wp_send_json_error(array('message' => 'Invalid request.'), 400);
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    if (!$email || !is_email($email)) wp_send_json_error(array('message' => 'Please enter a valid email.'), 422);
    $lead = array(
        'first_name' => lpai_clean('first_name'), 'last_name' => lpai_clean('last_name'),
        'email' => $email, 'phone' => lpai_clean('phone'), 'company' => lpai_clean('company'),
        'request_type' => lpai_clean('request_type'), 'qualification' => lpai_clean('qualification'),
        'cta_source' => lpai_clean('cta_source'), 'landing_page' => esc_url_raw(wp_unslash($_POST['landing_page'] ?? '')),
        'utm_source' => lpai_clean('utm_source'), 'utm_medium' => lpai_clean('utm_medium'),
        'utm_campaign' => lpai_clean('utm_campaign'), 'submitted_at' => current_time('mysql'),
    );
    if (empty($lead['first_name']) || empty($lead['last_name']) || empty($lead['phone'])) wp_send_json_error(array('message' => 'Please complete all required fields.'), 422);
    $post_id = wp_insert_post(array('post_type'=>'lpai_lead','post_status'=>'private','post_title'=>trim($lead['first_name'].' '.$lead['last_name']).' — '.$lead['request_type']));
    if (is_wp_error($post_id)) wp_send_json_error(array('message'=>'Unable to save the request.'),500);
    foreach ($lead as $key=>$value) update_post_meta($post_id, '_lpai_'.$key, $value);
    $webhook = trim((string)get_option('lpai_ghl_webhook', ''));
    if ($webhook) wp_remote_post($webhook, array('timeout'=>12,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode($lead)));
    wp_mail(get_option('admin_email'), 'New Lien Phat AI lead: '.$lead['request_type'], "Name: {$lead['first_name']} {$lead['last_name']}\nEmail: {$lead['email']}\nPhone: {$lead['phone']}\nCompany: {$lead['company']}\nRequest: {$lead['request_type']}\nQualification: {$lead['qualification']}");
    wp_send_json_success(array('message' => 'Your request has been received.'));
}
add_action('wp_ajax_lpai_submit_lead', 'lpai_submit_lead');
add_action('wp_ajax_nopriv_lpai_submit_lead', 'lpai_submit_lead');

function lpai_settings_menu() { add_theme_page('Lien Phat AI Settings','Lien Phat AI','manage_options','lpai-settings','lpai_settings_page'); }
add_action('admin_menu','lpai_settings_menu');
function lpai_settings_init() {
    register_setting('lpai_settings','lpai_ghl_webhook',array('sanitize_callback'=>'esc_url_raw'));
    register_setting('lpai_settings','lpai_calendar_url',array('sanitize_callback'=>'esc_url_raw'));
}
add_action('admin_init','lpai_settings_init');
function lpai_settings_page() { ?>
<div class="wrap"><h1>Lien Phat AI Settings</h1><form method="post" action="options.php"><?php settings_fields('lpai_settings'); ?>
<table class="form-table"><tr><th><label for="lpai_ghl_webhook">GoHighLevel webhook URL</label></th><td><input class="regular-text" type="url" id="lpai_ghl_webhook" name="lpai_ghl_webhook" value="<?php echo esc_attr(get_option('lpai_ghl_webhook','')); ?>"><p class="description">Optional. Submitted leads are also saved inside WordPress.</p></td></tr>
<tr><th><label for="lpai_calendar_url">Calendar URL</label></th><td><input class="regular-text" type="url" id="lpai_calendar_url" name="lpai_calendar_url" value="<?php echo esc_attr(get_option('lpai_calendar_url','')); ?>"></td></tr></table><?php submit_button(); ?></form></div><?php }

function lpai_document_title($parts) { if (is_front_page()) $parts['title']='AI Business Operating System | LIEN PHAT AI'; return $parts; }
add_filter('document_title_parts','lpai_document_title');

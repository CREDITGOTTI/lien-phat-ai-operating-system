<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="lp-section" style="padding-top:160px">
    <div class="lp-shell">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('lp-card'); ?> style="padding:30px;margin-bottom:20px">
                    <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                    <?php the_content(); ?>
                </article>
            <?php endwhile; ?>
            <?php the_posts_navigation(); ?>
        <?php else : ?>
            <h1><?php esc_html_e('Nothing found', 'lien-phat-ai'); ?></h1>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>

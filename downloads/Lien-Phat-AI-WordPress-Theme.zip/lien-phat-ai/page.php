<?php
if (!defined('ABSPATH')) exit;
get_header();
?>
<main class="lp-section" style="padding-top:160px">
    <div class="lp-shell">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h1><?php the_title(); ?></h1>
                <?php the_content(); ?>
            </article>
        <?php endwhile; ?>
    </div>
</main>
<?php get_footer(); ?>

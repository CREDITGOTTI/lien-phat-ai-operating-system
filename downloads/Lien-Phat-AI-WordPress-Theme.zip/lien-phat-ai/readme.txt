=== Lien Phat AI ===
Version: 1.2.0
Requires WordPress: 6.4+
Requires PHP: 8.0+

INSTALLATION
1. Back up the current WordPress site.
2. In WordPress Admin, open Appearance > Themes > Add New > Upload Theme.
3. Select Lien-Phat-AI-WordPress-Theme.zip and click Install Now.
4. When WordPress confirms installation, click Activate. WordPress intentionally keeps installation and activation as separate administrator actions.
5. Open Settings > Reading and set "Your homepage displays" to "A static page". Create/select a page named Home if WordPress requires one; this theme always renders the custom front page.
6. Open Appearance > Lien Phat AI.
7. Add the GoHighLevel inbound webhook URL if you want every lead forwarded to GHL.
8. Confirm the WordPress administrator email. Every submission is saved under Lien Phat Leads and emailed to the administrator.
9. Clear hosting/CDN caches and test the page on desktop and mobile.

WP-CLI INSTALL AND ACTIVATE
If your hosting account provides WP-CLI, an administrator can install and activate in one command:
wp theme install Lien-Phat-AI-WordPress-Theme.zip --activate

GOHIGHLEVEL
Create an inbound webhook/workflow in GoHighLevel and paste its URL under Appearance > Lien Phat AI. The theme sends first_name, last_name, email, phone, company, request_type, qualification, CTA source, landing page, UTM values, and submission time.

CONTENT AND DESIGN
This theme contains the complete Lien Phat AI one-page marketing experience: hero, statistics, system consolidation, customer journey, AI employees, Business Hub demo, automation, web systems, marketing, transformation, ROI calculator, pricing, industries, proof placeholders, FAQ, final CTA, responsive navigation, and lead modal.

SECURITY
Do not place API keys or passwords inside theme files. The lead endpoint uses a WordPress nonce, sanitizes fields, includes a honeypot, stores submissions privately, and can forward to a configured GHL webhook.

PRIVACY
Add final Privacy Policy, Terms, and Accessibility URLs before launch. Confirm SMS/email consent language with counsel and with the communication rules that apply to your business.

SUPPORT NOTES
No Node.js process is required after installation. The theme uses PHP, CSS, and vanilla JavaScript and can run on Hosting.com Managed WordPress or standard cPanel WordPress hosting.
